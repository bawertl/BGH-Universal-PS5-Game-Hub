#!/usr/bin/env python3
"""Copy ONLY these sources into a local PS5 Homebrew UI kit checkout.

Does not download dependencies, build, deploy, touch PS5, or run emulator code.
Never overwrites existing native UI kit files except its known factory list and registry
(after writing .ulg-backup sibling files).
"""
from pathlib import Path
import argparse
import shutil


def apply(project: Path, toolkit: Path) -> None:
    concepts = toolkit / 'src' / 'concepts'
    header = concepts / 'concepts.hpp'
    registry = concepts / 'registry.cpp'
    if not (header.is_file() and registry.is_file() and (toolkit/'Makefile').is_file()):
        raise SystemExit('Fehler: Kein gültiger Checkout von blackbearreloaded/ps5-homebrew-ui.')
    for path in (header, registry):
        backup = path.with_name(path.name + '.ulg-backup')
        if not backup.exists():
            shutil.copy2(path, backup)
    shutil.copy2(project/'native_ps5'/'universal_launcher.cpp', concepts/'universal_launcher.cpp')
    shutil.copy2(project/'native_ps5'/'library_core.hpp', concepts/'library_core.hpp')
    shutil.copy2(project/'native_ps5'/'library_core.cpp', concepts/'library_core.cpp')
    shutil.copy2(project/'native_ps5'/'launcher_client.cpp', concepts/'launcher_client.cpp')
    shutil.copy2(project/'native_ps5'/'launcher_client.hpp', concepts/'launcher_client.hpp')
    for file in ('state_store.cpp', 'state_store.hpp', 'cover_png.cpp', 'cover_png.hpp'):
        shutil.copy2(project/'native_ps5'/file, concepts/file)
    h = header.read_text(encoding='utf8')
    declaration = 'std::unique_ptr<app::Concept> make_universal_launcher(app::Context &context);'
    if declaration not in h:
        h = h.replace('} // namespace hui::concepts', declaration+'\n\n} // namespace hui::concepts')
        header.write_text(h,encoding='utf8')
    # The user requested ONE launcher, not the original 21 demonstration screens.
    registry.write_text("""// PS5 Universal Game Launcher. Includes exactly one application concept.
// SPDX-License-Identifier: MIT
#include "concepts/concepts.hpp"
namespace hui::app {
std::span<const ConceptFactory> concept_registry() {
    static constexpr ConceptFactory kFactories[] = {concepts::make_universal_launcher};
    return kFactories;
}
} // namespace hui::app
""", encoding='utf8')
    # The UI kit shell normally takes L1/R1 to switch between 21 demo screens.
    # With our single design, forward those exact actions to the launcher.
    shell=toolkit/'src'/'app'/'shell.cpp'
    if shell.is_file():
        original_shell=shell.read_text(encoding='utf8')
        if 'count > 1 && (input.is_pressed(Action::page_next)' not in original_shell:
            backup=shell.with_name('shell.cpp.ulg-backup')
            if not backup.exists():
                shutil.copy2(shell,backup)
            old='if (input.is_pressed(Action::page_next) || input.is_pressed(Action::page_prev))'
            if old not in original_shell:
                raise SystemExit('API der UI-Shell wurde geändert: L1/R1-Patch manuell prüfen.')
            original_shell=original_shell.replace(old,
                'if (count > 1 && (input.is_pressed(Action::page_next) || input.is_pressed(Action::page_prev)))',1)
            for suffix in ('pressed','released','held'):
                old='forwarded.'+suffix+' &= ~kShellActions;'
                if old not in original_shell:
                    raise SystemExit('UI-Shell-Eingabeänderung: kann sichere Weitergabe nicht belegen.')
                original_shell=original_shell.replace(old,
                    'forwarded.'+suffix+' &= ~(count == 1 ? action_bit(Action::touch) : kShellActions);',1)
            shell.write_text(original_shell,encoding='utf8')
    destination=toolkit/'assets'/'paths.conf'
    shutil.copy2(project/'assets'/'paths.conf',destination)
    shutil.copy2(project/'assets'/'cover_overrides.conf', toolkit/'assets'/'cover_overrides.conf')
    # cover_png.cpp uses zlib. The upstream boilerplate already builds pinned static zlib.
    # Modify the checkout Makefile only with a tagged, idempotent addition and backup.
    makefile=toolkit/'Makefile'
    original=makefile.read_text(encoding='utf8')
    marker='# PS5 UNIVERSAL LAUNCHER: PNG decode via pinned zlib'
    if marker not in original:
        backup=makefile.with_name('Makefile.ulg-backup')
        if not backup.exists():
            shutil.copy2(makefile,backup)
        inject=(marker+'\n'
                'APP_INCLUDE_PATHS += .deps/native/zlib/root/usr/include\n'
                'APP_STATIC_ARCHIVES += .deps/native/zlib/root/usr/lib/libz.a\n')
        # Must appear AFTER the defaults and BEFORE the override APP_INCLUDE_PATHS.
        where='OPENGL_SDK := .deps/ps5-opengl/current'
        if where in original:
            original=original.replace(where,inject+where,1)
        else:
            # Minimal test templates may have no upstream SDK declarations.
            # Append only; real console builders must still validate linking.
            original=original.rstrip()+'\n\n'+inject
        makefile.write_text(original,encoding='utf8')
    print('Overlay eingebunden (GUI, Cache, PNG, Startadapter). NOCH KEINE PS5-APP GEBAUT.')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('toolkit_checkout',type=Path)
    args=parser.parse_args()
    apply(Path(__file__).resolve().parents[1],args.toolkit_checkout.resolve())
