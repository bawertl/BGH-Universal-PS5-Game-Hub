# PS5 UNIVERSAL GAME LAUNCHER V0.5 – GITHUB BUILD STARTEN

**Diese Datei ist eine vollständig vorbereitete GitHub-Actions-Buildlösung, keine PS5-Anwendung.** Im Paket befindet sich kein fertiges `eboot.bin`. Der aktuelle Chat-Container hat keinen Zugriff auf die externen SDK-Downloads; außerdem ist kein beschreibbares GitHub-Projektrepository verfügbar. Der GitHub-Runner muss den echten PS5-Build ausführen.

## Einmaliger GitHub-Schritt – keine SDKs oder Compiler installieren

1. Öffne [github.com/new](https://github.com/new) und erstelle ein **leeres privates Repository**, z. B. `PS5-Universal-Game-Launcher`, mit Standardbranch `main`. Ein existierendes eigenes Repository ist ebenso möglich.
2. Entpacke **diese ZIP lokal**. Öffne im neuen Repository **Add file → Upload files**, und lade **den Inhalt des entpackten Projektordners** hoch: `native_ps5`, `tooling`, `tests`, `assets`, `src` sowie unbedingt `.github/workflows/ps5-build.yml` und die übrigen Projektdateien. Committe die Dateien nach `main`. **Nicht die ZIP als einzelne Datei hochladen!**
3. **Wichtig bei Browser-Uploads:** Einige Browser behandeln `.github` als versteckten Ordner und laden ihn nicht mit hoch. Überprüfe, dass die Datei `.github/workflows/ps5-build.yml` tatsächlich im GitHub-Repository sichtbar ist. Falls nicht: In GitHub unter **Add file → Create new file** exakt `.github/workflows/ps5-build.yml` anlegen und den bereits vorbereiteten Inhalt aus `GITHUB_ACTIONS_WORKFLOW.txt` einfügen. Alternativ mit GitHub Desktop hochladen. Das ist nur die Workflow-Datei – du musst den Programmcode nicht bearbeiten.
4. Der Commit löst den Workflow über `on: push` automatisch aus. Wenn GitHub Actions für das Repository noch nicht aktiviert ist, aktiviere es unter **Actions**. Den vorhandenen Workflow kannst du dort auch über **Run workflow** manuell starten.

## So kommt die echte PS5-Datei

Öffne den durchlaufenden Workflow **PS5 Universal Game Launcher – Native Build** unter **Actions**.

- **Grün:** Unter **Artifacts** erscheint `PS5-Universal-Game-Launcher-PPSA99079-TEST`. Der Workflow benutzt `actions/upload-artifact@v7` mit `archive: false`, damit die fertig gebaute PS5-ZIP **direkt**, ohne eine zweite ZIP-Hülle, abrufbar ist. Dateiname: `PS5_Universal_Game_Launcher_PPSA99079_PS5_TEST.zip`.
- **Rot:** Lade `PS5-Launcher-Compiler-Error-Log` herunter oder kopiere die Fehlermeldung aus der Build-Aktion. Schicke mir den Log, damit ich konkrete Compiler- oder Linkerfehler am unveränderten V0.5-Stand korrigieren kann. Den roten Build niemals auf die PS5 übertragen.

## Erst wenn der echte PS5-Build grün ist

1. Vor der FTP-Übertragung auf deiner PS5 kontrollieren, ob die Entwicklungs-Title-ID `PPSA99079` **noch nicht** von einer anderen App belegt wird. **Nicht überschreiben**.
2. Die heruntergeladene **PS5-TEST-ZIP entpacken**. Darin muss sich der vollständige Ordner `PPSA99079` mit `eboot.bin`, `sce_module/libc.prx`, `sce_sys/param.json` und `assets` befinden.
3. Den **ganzen Ordner** per bestehendem FTP-Zugang nach `/data/homebrew/PPSA99079` übertragen. Dateirechte des PS5-Pakets beibehalten. Keinen einzelnen ELF- oder Linux-Host-Build auf die Konsole übertragen.
4. Mit deinem **bereits vorhandenen ShadowMountPlus** die App registrieren und über den neuen Eintrag im PS5-Hauptmenü starten, sofern deine aktuelle Konfiguration diese Registrierung erlaubt.
5. Bei der ersten Ausführung **nur die Bibliothek überprüfen**. Die App verändert keine Spieleordner und installiert keine Payloads. Ob ein sandboxed Homebrew-Titel auf Firmware 13.60 `/data` und USB lesen kann, ist derzeit **nicht hardwarebestätigt**. Falls die Bibliothek leer ist, den Ordnerstatus in **Einstellungen** ansehen, nicht sofort Payloads ändern.

## Was der Workflow vor dem Download erzwingt

- Pinnen des öffentlichen PS5-Homebrew-UI-Commits `bbe19054ee2e7ec069254775273aeb8846c4bd3e`.
- Host-Regressionstests und GUI-Syntaxprüfung.
- SDK/PS5-OpenGL aus den offiziellen Buildskripten des geklonten Kits; keine proprietären SDK-Dateien im Upload.
- Echter SDK-Link-Schritt und PS5-FSELF-Erzeugung durch das Upstream-Kit.
- Original-ZIP des UI-Kits **nicht neu verpacken**, um dessen `0777`-ZIP-Rechte zu erhalten.
- Prüfen von ZIP-CRC, Metadaten, Pfaden, `eboot.bin`- und `libc.prx`-Signaturen, `0777`-Rechten und SHA-256.
- Strikte Trennung zwischen erfolgreich erzeugtem PS5-Dateiformat und **noch fehlendem PS5-Firmware-13.60-Hardwaretest**.

Es gibt weiterhin **keine** Installations- oder Änderungsaktion auf der echten PS5 durch diesen Workflow.
