// PS5 Universal Launcher - portable, read-only, POSIX game directory scanner.
// SPDX-License-Identifier: MIT
#pragma once
#include <cstddef>
#include <string>
#include <vector>

namespace ulg {
struct Root { std::string platform, path; };
struct Game {
    std::string id, title, platform, path, format, title_id, cover_path;
    bool available = true;
};
struct RootState { std::string platform, path, status; }; // ok/offline/zugriff_verweigert/fehler
struct Catalogue {
    std::vector<Game> games;
    std::vector<RootState> roots;
    std::vector<std::string> errors;
    bool truncated = false;
};
// With no file, returns conservative documented default candidates; never writes.
std::vector<Root> load_roots(const std::string &config_path);
Catalogue scan(const std::vector<Root> &roots, int max_depth = 5, std::size_t max_games = 5000);
// Host/test utility. Caller chooses output path outside game folders.
// Applies explicit game-ID or absolute game-path -> absolute local PNG cover overrides.
void apply_cover_overrides(Catalogue &catalogue, const std::string &config_path);
Catalogue merge_unavailable(Catalogue fresh, const Catalogue &previous);
// Host/test utility. Caller chooses output path outside game folders.
bool write_json(const Catalogue &catalogue, const std::string &output_path);
} // namespace ulg
