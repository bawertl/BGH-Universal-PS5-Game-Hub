// PS5 Universal Game Launcher - UI component for blackbearreloaded/ps5-homebrew-ui.
// SPDX-License-Identifier: MIT
// Launch requests occur ONLY after explicit DualSense confirmation; no elevation or registration.
// To integrate, run tooling/install_ui_kit_overlay.py against a local checkout of ps5-homebrew-ui.
#include "concepts/concepts.hpp"
#include "concepts/library_core.hpp"
#include "concepts/state_store.hpp"
#include "concepts/cover_png.hpp"
#include "concepts/launcher_client.hpp"
#include "ui/glyphs.hpp"
#include "platform/ps5/system.hpp"
#include "ui/motion.hpp"
#include <algorithm>
#include <array>
#include <map>
#include <deque>
#include <cstdint>
#include <GL/glcorearb.h>
#include <cerrno>
#include <dirent.h>
#include <sys/types.h>
#include <cstdio>
#include <cstring>
#include <set>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace hui::concepts {
namespace {
using gfx::Color;
using gfx::Rect;
const Color kInk = Color::rgb(0xEDF1FF);
const Color kMuted = Color::rgb(0x9AA6BE);
const Color kAccent = Color::rgb(0x859AFF);
constexpr int kColumns = 6;
constexpr int kRows = 2;
constexpr int kPageSize = kColumns * kRows;
constexpr float kLeft = 82.0f;
constexpr float kTop = 332.0f;
constexpr float kCardW = 247.0f;
constexpr float kCardH = 265.0f;
constexpr float kGapX = 38.0f;
constexpr float kGapY = 27.0f;
constexpr std::array<const char *, 8> kTabs = {
    "Alle Spiele", "PS5", "PS4", "PS2", "Switch", "Xbox 360", "Favoriten", "Zuletzt gestartet"
};
constexpr const char *kTechniques[] = {
    "Lokaler POSIX-Scan ohne Schreibzugriff auf Spieleordner",
    "Native OpenGL-GUI mit DualSense und Plattformfiltern",
    "Spielstart erfolgt ausschliesslich nach expliziter Aktion und nur via vorhandenen Forwarder-Dienst"
};
std::string shorten(const std::string &s, std::size_t limit) {
    if(s.size() <= limit)return s;
    if(limit<4)return s.substr(0,limit);
    return s.substr(0,limit-3)+"...";
}
Color platform_color(const std::string &p){
    if(p=="PS5")return Color::rgb(0x4D6FFF);
    if(p=="PS4")return Color::rgb(0x4C91D8);
    if(p=="PS2")return Color::rgb(0xA182FD);
    if(p=="Switch")return Color::rgb(0xED646B);
    if(p=="Xbox 360")return Color::rgb(0x62C09A);
    return Color::rgb(0x7985A9);
}
class CoverTextures {
public:
    // Called only from update() while a GL context is current; draw() performs no file I/O.
    void load(const std::string &path) {
        if(path.empty() || textures_.count(path)) return;
        std::uint32_t texture = 0;
        if(path.size()>4 && path.substr(path.size()-4)==".png") {
            ulg::PngImage image;
            if(ulg::decode_png(path,image)) {
                GLuint gl_id=0;
                glGenTextures(1,&gl_id);
                if(gl_id){
                    glBindTexture(GL_TEXTURE_2D,gl_id);
                    glPixelStorei(GL_UNPACK_ALIGNMENT,4);
                    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,image.width,image.height,0,GL_RGBA,GL_UNSIGNED_BYTE,image.rgba.data());
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAX_LEVEL,0);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
                    texture=gl_id;
                }
            }
        }
        if(order_.size()>=48){
            const auto previous=order_.front();order_.pop_front();
            const GLuint old=static_cast<GLuint>(textures_[previous]);
            if(old)glDeleteTextures(1,&old);
            textures_.erase(previous);
        }
        textures_[path]=texture;order_.push_back(path);
    }
    bool has(const std::string &path) const {return textures_.count(path)>0;}
    std::uint32_t get(const std::string &path) const {
        const auto it=textures_.find(path);
        return it==textures_.end()?0:it->second;
    }
    void clear(){
        for(const auto &item:textures_){const GLuint texture=static_cast<GLuint>(item.second);if(texture)glDeleteTextures(1,&texture);}
        textures_.clear();order_.clear();
    }
    ~CoverTextures(){clear();}
private:
    std::map<std::string,std::uint32_t> textures_;
    std::deque<std::string> order_;
};
class UniversalLauncher final : public app::Concept {
public:
    explicit UniversalLauncher(app::Context &context) : context_(context) {
        // All writes are restricted to this title's own storage, never game directories.
        (void)mkdir("/download0/hui",0700);
        (void)mkdir(kStateFolder,0700);
        ulg::Preferences preferences;
        if(ulg::read_preferences(kPrefsFile,preferences)){
            favorites_=std::move(preferences.favorites);
            recent_list_=std::move(preferences.recent);
        }
        for(const auto &id:recent_list_)recent_.insert(id);
        if(!ulg::read_catalogue_cache(kCacheFile,catalogue_))refresh();
        else{
            validate_cached_roots();
            ulg::apply_cover_overrides(catalogue_,"/app0/assets/cover_overrides.conf");
            rebuild();
        }
    }
    const app::ConceptInfo &info() const override {
        static const app::ConceptInfo kInfo{
            "universal_launcher", "Universal Game Launcher",
            "Deine Spiele. Eine Bibliothek. Komplett lokal.",
            "src/concepts/universal_launcher.cpp", audio::SoundSet::glass, kAccent, kTechniques
        };
        return kInfo;
    }
    void enter() override { clock_=0.0f; }
    void update(const InputFrame &input, float dt, app::Feedback &feedback) override {
        clock_ += dt;
        load_next_visible_cover();
        if(input.is_pressed(Action::back)){
            if(search_open_){search_open_=false;feedback.play(audio::Cue::back);}
            else if(detail_ || settings_){detail_=false;settings_=false;feedback.play(audio::Cue::back);}
            return;
        }
        if(input.is_pressed(Action::menu)){
            detail_=false;search_open_=false;settings_=!settings_;
            feedback.play(audio::Cue::open);return;
        }
        if(search_open_){update_search(input,feedback);return;}
        if(settings_){
            if(input.is_pressed(Action::west)){refresh();feedback.play(audio::Cue::select);}
            return;
        }
        if(detail_){
            if(input.is_pressed(Action::north))toggle_favorite();
            if(input.is_pressed(Action::confirm) && !indices_.empty()){
                const auto &g=catalogue_.games[indices_[static_cast<std::size_t>(selected_)]];
                const auto plan=ulg::make_launch_plan(g.platform,g.path);
                if(!g.available){launch_message_="USB-Laufwerk / Spiel nicht verfügbar";feedback.play(audio::Cue::error);}
                else if(!plan.supported){launch_message_=plan.reason;feedback.play(audio::Cue::error);}
                else {
                    struct stat current{};
                    if(lstat(g.path.c_str(),&current)!=0 || (!S_ISREG(current.st_mode) && !S_ISDIR(current.st_mode))){
                        launch_message_="Spiel / USB-Datentraeger nicht mehr verfuegbar";
                        feedback.play(audio::Cue::error);
                    }else{
                        const auto result=ulg::send_launch(plan);
                        launch_message_=result.message;
                        if(result.status==ulg::LaunchStatus::queued || result.status==ulg::LaunchStatus::started){
                            record_recent(g.id);feedback.play(audio::Cue::launch);
                            // The queued PS5 launch completes after the current title closes.
                            if(result.status==ulg::LaunchStatus::queued)sys::quit();
                        }else feedback.play(audio::Cue::error);
                    }
                }
            }
            return;
        }
        if(input.is_pressed(Action::page_prev)){tab_=tab_==0?static_cast<int>(kTabs.size()-1):tab_-1;rebuild();feedback.play(audio::Cue::tab);}
        if(input.is_pressed(Action::page_next)){tab_=(tab_+1)%static_cast<int>(kTabs.size());rebuild();feedback.play(audio::Cue::tab);}
        if(input.is_pressed(Action::west)){refresh();feedback.play(audio::Cue::select);}
        if(input.is_pressed(Action::north)){
            search_open_=true;search_key_=0;feedback.play(audio::Cue::open);return;
        }
        if(input.nav!=Direction::none && !indices_.empty()) {
            int candidate=selected_;
            switch(input.nav){
                case Direction::left: candidate-=1;break;
                case Direction::right: candidate+=1;break;
                case Direction::up: candidate-=kColumns;break;
                case Direction::down: candidate+=kColumns;break;
                default: break;
            }
            candidate=std::clamp(candidate,0,static_cast<int>(indices_.size()-1));
            if(candidate!=selected_){selected_=candidate;feedback.play(audio::Cue::focus);}
        }
        if(input.is_pressed(Action::confirm) && !indices_.empty()){
            detail_=true;launch_message_.clear();feedback.play(audio::Cue::open);
        }
    }
    void draw(app::Frame &frame) const override {
        frame.backdrop.mode=gfx::BackdropMode::aurora;
        frame.backdrop.colors[0]=Color::rgb(0x070B13);
        frame.backdrop.colors[1]=Color::rgb(0x151931);
        frame.backdrop.colors[2]=Color::rgb(0x1D2252);
        frame.backdrop.colors[3]=Color::rgb(0x37255F);
        frame.backdrop.time=clock_;
        auto &list=frame.scene;
        const auto &fonts=context_.fonts;
        list.rounded_rect({52,40,1816,110},28,Color::rgb(0x161D2D,0.93f));
        list.rounded_rect({76,69,9,52},4,kAccent);
        ui::text(list,fonts.semibold,"UNIVERSAL GAME LAUNCHER",105,100,33,kInk);
        ui::text(list,fonts.regular,"PS5  /  LOKALE BIBLIOTHEK",105,130,20,kMuted);
        ui::text(list,fonts.semibold,"V0.4 ENTWICKLUNGSVERSION",1470,107,18,kAccent);
        for (int i=0;i<static_cast<int>(kTabs.size());++i) {
            const float x=80 + i*216;
            list.rounded_rect({x,170,202,53},16,i==tab_?Color::rgb(0x5665AF,0.75f):Color::rgb(0x252B3F,0.65f));
            ui::text(list,fonts.semibold,kTabs[static_cast<std::size_t>(i)],x+15,204,19,i==tab_?kInk:kMuted);
        }
        std::string counter=std::to_string(indices_.size())+" Spiele";
        ui::text(list,fonts.display,"Meine Spielebibliothek",83,292,45,kInk);
        if(!search_query_.empty())ui::text(list,fonts.regular,"Suche: "+shorten(search_query_,24),720,292,23,kAccent);
        ui::text(list,fonts.semibold,counter,1660,286,23,kAccent);
        if(indices_.empty()){
            list.rounded_rect({82,338,1753,510},30,Color::rgb(0x1C2334,0.85f));
            ui::text(list,fonts.display,"Keine Spiele angezeigt",140,470,46,kInk);
            ui::text(list,fonts.regular,"Quadrat: Ordner erneut pruefen  |  OPTIONS: Pfadstatus",140,524,26,kMuted);
        } else {
            int page=selected_/kPageSize;
            std::size_t first=static_cast<std::size_t>(page*kPageSize);
            std::size_t last=std::min(first+kPageSize,indices_.size());
            for(std::size_t j=first;j<last;++j)draw_card(list,catalogue_.games[indices_[j]],static_cast<int>(j-first),static_cast<int>(j)==selected_);
            std::string pagination="Seite "+std::to_string(page+1)+" / "+std::to_string((indices_.size()+kPageSize-1)/kPageSize);
            ui::text(list,fonts.regular,pagination,1450,944,20,kMuted);
        }
        list.rounded_rect({70,970,1780,76},22,Color::rgb(0x11192A,0.91f));
        const ui::Hint hints[]={
            {ui::Button::cross,"Details"},{ui::Button::circle,"Zurueck"},
            {ui::Button::l1,"Plattform",ui::Button::r1},
            {ui::Button::square,"Aktualisieren"},{ui::Button::triangle,"Suche"},
            {ui::Button::options,"Einstellungen"}
        };
        ui::HintLayout hint_layout;hint_layout.cy=1009;hint_layout.size=28;hint_layout.text_size=19;hint_layout.item_gap=34;
        ui::draw_hints(list,fonts,ui::GlyphStyle::dark(),hints,6,109,false,hint_layout);
        if(detail_)draw_detail(frame);
        if(settings_)draw_settings(frame);
        if(search_open_)draw_search(frame);
    }
private:
    static constexpr const char *kStateFolder="/download0/hui/ulg_v04";
    static constexpr const char *kCacheFile="/download0/hui/ulg_v04/library.bin";
    static constexpr const char *kPrefsFile="/download0/hui/ulg_v04/preferences.bin";
    void save_prefs(){
        ulg::Preferences pref;pref.favorites=favorites_;pref.recent=recent_list_;
        (void)ulg::write_preferences(pref,kPrefsFile);
    }
    void record_recent(const std::string &id){
        recent_list_.erase(std::remove(recent_list_.begin(),recent_list_.end(),id),recent_list_.end());
        recent_list_.insert(recent_list_.begin(),id);
        if(recent_list_.size()>80)recent_list_.resize(80);
        recent_.insert(id);save_prefs();
    }
    void validate_cached_roots(){
        for(auto &root:catalogue_.roots){
            struct stat st{};
            if(lstat(root.path.c_str(),&st)!=0 || !S_ISDIR(st.st_mode))root.status="offline";
            else {
                DIR *probe=opendir(root.path.c_str());
                if(!probe)root.status=(errno==EACCES ? "zugriff_verweigert" : "fehler");
                else {closedir(probe);root.status="ok";}
            }
        }
        for(auto &g:catalogue_.games){
            // Cached USB game may have been removed while its mount remains.
            // Revalidate only one known file, never rescan its entire directory.
            struct stat game_stat{};
            if(lstat(g.path.c_str(),&game_stat)!=0 ||
               (!S_ISREG(game_stat.st_mode) && !S_ISDIR(game_stat.st_mode)))
                g.available=false;
            for(const auto &r:catalogue_.roots){
                if(r.status!="ok" && g.path.size()>r.path.size() &&
                   g.path.compare(0,r.path.size(),r.path)==0 && g.path[r.path.size()]=='/'){
                    g.available=false;break;
                }
            }
        }
    }
    void load_next_visible_cover(){
        if(indices_.empty())return;
        const std::size_t page=static_cast<std::size_t>(selected_/kPageSize);
        const std::size_t first=page*kPageSize;
        for(std::size_t i=first;i<std::min(first+kPageSize,indices_.size());++i){
            const auto &g=catalogue_.games[indices_[i]];
            if(g.available && !g.cover_path.empty() && !covers_.has(g.cover_path)){
                covers_.load(g.cover_path);break; // at most one picture each update
            }
        }
    }
    void refresh() {
        const std::string selected_id=(!indices_.empty() && selected_<static_cast<int>(indices_.size())) ?
            catalogue_.games[indices_[static_cast<std::size_t>(selected_)]].id : "";
        const auto roots=ulg::load_roots("/app0/assets/paths.conf");
        catalogue_=ulg::merge_unavailable(ulg::scan(roots,5,5000),catalogue_);
        ulg::apply_cover_overrides(catalogue_,"/app0/assets/cover_overrides.conf");
        (void)ulg::write_catalogue_cache(catalogue_,kCacheFile);
        covers_.clear();
        ++refresh_count_;rebuild();
        if(!selected_id.empty())for(std::size_t i=0;i<indices_.size();++i)
            if(catalogue_.games[indices_[i]].id==selected_id){selected_=static_cast<int>(i);break;}
    }
    static constexpr const char *kSearchKeys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 <-";
    void update_search(const InputFrame &input,app::Feedback &feedback){
        constexpr int columns=9;
        const int count=static_cast<int>(std::strlen(kSearchKeys));
        int next=search_key_;
        if(input.nav==Direction::left)next-=1;
        if(input.nav==Direction::right)next+=1;
        if(input.nav==Direction::up)next-=columns;
        if(input.nav==Direction::down)next+=columns;
        next=std::clamp(next,0,count-1);
        if(next!=search_key_){search_key_=next;feedback.play(audio::Cue::focus);}
        if(input.is_pressed(Action::west) || input.is_pressed(Action::north)){
            if(!search_query_.empty())search_query_.pop_back();rebuild();
        }
        if(input.is_pressed(Action::confirm)){
            const char key=kSearchKeys[search_key_];
            if(key=='<'){if(!search_query_.empty())search_query_.pop_back();}
            else if(key=='-'){search_open_=false;}
            else if(search_query_.size()<48)search_query_+=key;
            rebuild();feedback.play(audio::Cue::select);
        }
    }
    void draw_search(app::Frame &frame) const {
        frame.glass=true;
        auto &list=frame.overlay;const auto &fonts=context_.fonts;
        list.rounded_rect({327,160,1268,754},32,Color::rgb(0x151D2D,0.98f));
        ui::text(list,fonts.display,"Spiele suchen",385,245,45,kInk);
        list.rounded_rect({385,277,1150,80},16,Color::rgb(0x26314C));
        ui::text(list,fonts.semibold,search_query_.empty()?"Titel eingeben ...":search_query_,415,328,31,kInk);
        const int count=static_cast<int>(std::strlen(kSearchKeys));
        for(int i=0;i<count;++i){
            const int col=i%9,row=i/9;
            const float x=391+col*126.0f,y=395+row*95.0f;
            list.rounded_rect({x,y,109,74},13,i==search_key_?Color::rgb(0x596DBA):Color::rgb(0x273146));
            const char letter=kSearchKeys[i];
            std::string caption=letter==' '?"LEER":(letter=='<'?"LOESCHEN":(letter=='-'?"FERTIG":std::string(1,letter)));
            ui::text(list,fonts.semibold,caption,x+13,y+48,letter==' '||letter=='<'||letter=='-'?16:27,kInk);
        }
        ui::text(list,fonts.regular,"X: Buchstabe    Dreieck: Loeschen    Kreis: Fertig",400,867,22,kMuted);
    }
    void rebuild(){
        indices_.clear();
        for(std::size_t i=0;i<catalogue_.games.size();++i){
            const auto &g=catalogue_.games[i];
            bool show=tab_==0 || (tab_>=1 && tab_<=5 && g.platform==kTabs[static_cast<std::size_t>(tab_)]) ||
                      (tab_==6 && favorites_.count(g.id)>0) || (tab_==7 && recent_.count(g.id)>0);
            if(show && !search_query_.empty()){
                auto name=g.title;
                for(char &c:name)if(c>='a' && c<='z')c=static_cast<char>(c-'a'+'A');
                show=name.find(search_query_)!=std::string::npos;
            }
            if(show)indices_.push_back(i);
        }
        if(indices_.empty())selected_=0;
        else selected_=std::clamp(selected_,0,static_cast<int>(indices_.size()-1));
    }
    void toggle_favorite(){
        if(indices_.empty())return;
        auto &id=catalogue_.games[indices_[static_cast<std::size_t>(selected_)]].id;
        if(!favorites_.insert(id).second)favorites_.erase(id);
        save_prefs();rebuild();
    }
    void draw_card(gfx::DrawList &list,const ulg::Game &game,int index,bool selected) const {
        const auto &fonts=context_.fonts;
        const int col=index%kColumns,row=index/kColumns;
        const float x=kLeft+col*(kCardW+kGapX),y=kTop+row*(kCardH+kGapY);
        const auto accent=platform_color(game.platform);
        if(selected)list.glow({x-5,y-5,kCardW+10,kCardH+10},23,23,Color::rgb(0x7796FF,0.47f));
        list.rounded_rect({x,y,kCardW,kCardH},18,selected?Color::rgb(0x4D6097):Color::rgb(0x1C2638));
        const auto cover=covers_.get(game.cover_path);
        if(cover && game.available)list.image(cover,{x+4,y+4,kCardW-8,kCardH-8},gfx::kFullUv,Color::rgb(0xFFFFFF),15);
        else{
            list.gradient_rect({x+5,y+5,kCardW-10,kCardH-10},16,Color::rgb(0x172342),accent.with_alpha(0.55f));
            ui::text(list,fonts.display,game.platform,x+22,y+111,35,kInk);
            ui::text(list,fonts.regular,"KEIN LOKALES COVER",x+20,y+155,14,kMuted);
        }
        list.rounded_rect({x+5,y+kCardH-83,kCardW-10,78},12,Color::rgb(0x0B1020,0.92f));
        ui::text(list,fonts.semibold,shorten(game.title,22),x+19,y+kCardH-46,20,kInk);
        ui::text(list,fonts.regular,game.available?game.platform:"USB OFFLINE",x+19,y+kCardH-18,16,game.available?accent:Color::rgb(0xFFAC86));
        if(favorites_.count(game.id))list.star(x+kCardW-28,y+27,12,Color::rgb(0xFFE3A0));
        if(selected)list.bordered_rect({x,y,kCardW,kCardH},18,Color::rgb(0xFFFFFF,0.0f),4,kAccent);
    }
    void draw_detail(app::Frame &frame) const {
        auto &list=frame.overlay;const auto &fonts=context_.fonts;
        if(indices_.empty())return;
        const auto &g=catalogue_.games[indices_[static_cast<std::size_t>(selected_)]];
        frame.glass=true;
        list.rounded_rect({265,125,1390,790},36,Color::rgb(0x151D2D,0.97f));
        list.rounded_rect({315,186,350,525},28,Color::rgb(0x26314C));
        list.rounded_rect({345,215,137,50},16,platform_color(g.platform));
        ui::text(list,fonts.semibold,g.platform,359,251,29,Color::rgb(0xFFFFFF));
        const auto cover=covers_.get(g.cover_path);
        if(cover && g.available)list.image(cover,{320,192,340,513},gfx::kFullUv,Color::rgb(0xFFFFFF),22);
        else{
            ui::text(list,fonts.display,"COVER",354,516,57,kMuted);
            ui::text(list,fonts.regular,"Kein PNG-Cover gefunden",344,653,21,kMuted);
        }
        ui::text(list,fonts.display,shorten(g.title,35),710,244,43,kInk);
        ui::text(list,fonts.semibold,"Plattform: "+g.platform,710,309,27,kAccent);
        ui::text(list,fonts.regular,"Format: "+g.format,710,353,23,kMuted);
        ui::text(list,fonts.regular,"Spielpfad:",710,401,23,kMuted);
        ui::text(list,fonts.regular,shorten(g.path,78),710,436,20,kInk);
        const auto plan=ulg::make_launch_plan(g.platform,g.path);
        const bool can_start=plan.supported && g.available;
        list.rounded_rect({711,506,800,125},20,can_start?Color::rgb(0x3D527C):Color::rgb(0x2C3044));
        ui::text(list,fonts.semibold,can_start?"X  SPIEL STARTEN":(g.available?"DIREKTSTART NICHT VERFUEGBAR":"SPIEL NICHT VERFUEGBAR"),740,559,27,can_start?kInk:kMuted);
        ui::text(list,fonts.regular,can_start?"Vorhandener PS5-Startdienst erforderlich":(g.available?plan.reason:"Datentraeger erneut anschliessen"),740,599,20,Color::rgb(0xFFB982));
        if(!launch_message_.empty())ui::text(list,fonts.regular,shorten(launch_message_,90),714,684,22,kAccent);
        ui::text(list,fonts.regular,"Dreieck: Favorit   |   Kreis: Zurueck",720,736,23,kMuted);
    }
    void draw_settings(app::Frame &frame) const {
        frame.glass=true;
        auto &list=frame.overlay;const auto &fonts=context_.fonts;
        list.rounded_rect({260,116,1400,827},35,Color::rgb(0x151D2D,0.98f));
        ui::text(list,fonts.display,"Einstellungen / Ordnerstatus",318,215,46,kInk);
        ui::text(list,fonts.regular,"Zugriff auf /data haengt von den PS5-App-Berechtigungen ab.",318,272,22,kMuted);
        int y=329;int count=0;
        for(const auto &root:catalogue_.roots) {
            if(++count>11)break;
            const bool ok=root.status=="ok";
            list.rounded_rect({311,static_cast<float>(y-27),1332,44},11,Color::rgb(0x242E42));
            ui::text(list,fonts.semibold,root.platform,335,static_cast<float>(y+3),18,platform_color(root.platform));
            ui::text(list,fonts.regular,shorten(root.path,70),505,static_cast<float>(y+3),18,kInk);
            ui::text(list,fonts.semibold,ok?"OK":root.status,1332,static_cast<float>(y+3),18,ok?Color::rgb(0x8ADDAC):Color::rgb(0xF6B17C));
            y+=50;
        }
        std::string summary="Scanlaeufe: "+std::to_string(refresh_count_)+" | Fehler: "+std::to_string(catalogue_.errors.size());
        ui::text(list,fonts.regular,summary,321,899,20,kMuted);
        ui::text(list,fonts.regular,"Quadrat: Erneut scannen    Kreis / OPTIONS: Schliessen",750,899,19,kAccent);
    }
    app::Context &context_;
    ulg::Catalogue catalogue_;
    std::vector<std::size_t> indices_;
    std::set<std::string> favorites_;
    std::set<std::string> recent_;
    std::vector<std::string> recent_list_;
    CoverTextures covers_;
    float clock_=0;
    int tab_=0,selected_=0,refresh_count_=0;
    bool detail_=false,settings_=false,search_open_=false;
    std::string search_query_;
    int search_key_=0;
    std::string launch_message_;
};
} // namespace
std::unique_ptr<app::Concept> make_universal_launcher(app::Context &context) {
    return std::make_unique<UniversalLauncher>(context);
}
} // namespace hui::concepts
