// SPDX-License-Identifier: MIT
// No PS5 SDK required. opendir/readdir/lstat/open/read only during scanning.
// No symlink traversal. Limits for recursion, records and unusually long paths.
#include "library_core.hpp"
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <dirent.h>
#include <set>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

namespace ulg {
namespace {
struct Child { std::string name, path; bool folder; };
std::string lowercase(std::string s) {
    for (char &c : s) if (c >= 'A' && c <= 'Z') c = static_cast<char>(c + ('a' - 'A'));
    return s;
}
bool ends(const std::string &s, const std::string &suffix) {
    return s.size() >= suffix.size() && s.compare(s.size() - suffix.size(),suffix.size(),suffix)==0;
}
std::string basename(const std::string &s) {
    auto pos = s.find_last_of('/'); return pos==std::string::npos ? s : s.substr(pos+1);
}
std::string title_from(std::string s) {
    std::string low=lowercase(s);
    static const char *extensions[]={".iso",".chd",".cso",".zso",".nsp",".xci",".xex",".cue",".pbp"};
    for (const char *ext:extensions) if (ends(low,ext)) {s.resize(s.size()-std::strlen(ext));break;}
    for (char &c:s) if (c=='_' || c=='.') c=' ';
    if (s.empty()) return "Unbenanntes Spiel";
    return s;
}
std::string extension(const std::string &s) {
    auto pos=s.find_last_of('.');return pos==std::string::npos?"":lowercase(s.substr(pos));
}
std::string format_for(const std::string &platform,const std::string &path) {
    const std::string e=extension(path);
    if(platform=="PS2" && (e==".iso" || e==".chd" || e==".cso" || e==".zso")) return e.substr(1);
    if(platform=="Switch" && (e==".nsp" || e==".xci")) return e.substr(1);
    if(platform=="Xbox 360" && (e==".iso" || (e==".xex" && lowercase(basename(path))=="default.xex"))) return e.substr(1);
    if(platform=="PS1" && (e==".cue" || e==".chd")) return e.substr(1);
    if(platform=="PSP" && (e==".iso" || e==".cso" || e==".chd" || e==".pbp"))return e.substr(1);
    return "";
}
bool is_file(const std::string &p) {struct stat st{};return lstat(p.c_str(),&st)==0 && S_ISREG(st.st_mode);}
std::string classify_native(const std::string &folder) {
    auto b=lowercase(basename(folder));
    if(b.compare(0,4,"cusa")==0)return "PS4";
    if(b.compare(0,4,"ppsa")==0)return "PS5";
    if(is_file(folder+"/PS4_GAME/PARAM.SFO"))return "PS4";
    return "PS5/PS4";
}
std::string local_cover(const std::string &game_path, bool folder_game, const std::string &title_id) {
    const std::string folder = folder_game ? game_path : game_path.substr(0, game_path.find_last_of('/'));
    const std::string stem = basename(game_path).substr(0, basename(game_path).find_last_of('.'));
    // Native renderer decodes PNG only. Prefer a displayable PNG to JPEG
    // even if a similarly named JPEG exists (JPEG remains metadata-only).
    const char *names[] = {"cover.png","folder.png","icon.png","poster.png",
                           "boxart.png","sce_sys/icon0.png", "cover.jpg","cover.jpeg",
                           "folder.jpg","icon.jpg"};
    for (const char *name : names) {
        const std::string candidate = folder + "/" + name;
        if (is_file(candidate)) return candidate;
    }
    for (const auto &extension : {".png", ".jpg", ".jpeg"}) {
        const std::string candidate = folder + "/" + stem + extension;
        if (is_file(candidate)) return candidate;
    }
    (void)title_id;
    return {};
}
struct NativeMeta { std::string title, title_id; };
// Conservative string extraction for common param.json fields; accepts no more than 256 KiB.
std::string small_file(const std::string &path){
    FILE *f=std::fopen(path.c_str(),"rb");if(!f)return {};
    if(std::fseek(f,0,SEEK_END)!=0){std::fclose(f);return {};}
    const long size=std::ftell(f);
    if(size<0 || size>262144 || std::fseek(f,0,SEEK_SET)!=0){std::fclose(f);return {};}
    std::string bytes(static_cast<std::size_t>(size),'\0');
    const bool read=bytes.empty() || std::fread(bytes.data(),1,bytes.size(),f)==bytes.size();
    std::fclose(f);return read?bytes:std::string{};
}
std::string json_field(const std::string &s,const std::string &name){
    const std::string key="\""+name+"\"";
    const std::size_t found=s.find(key);
    if(found==std::string::npos)return {};
    auto colon=s.find(':',found+key.size());
    if(colon==std::string::npos)return {};
    auto begin=s.find('\"',colon+1);
    if(begin==std::string::npos)return {};
    std::string result;
    for(std::size_t i=begin+1;i<s.size() && result.size()<300;++i){
        const char ch=s[i];
        if(ch=='\"')return result;
        if(ch=='\\' && i+1<s.size()){
            const char escaped=s[++i];
            if(escaped=='\"'||escaped=='\\'||escaped=='/')result+=escaped;
            else if(escaped=='n'||escaped=='r'||escaped=='t')result+=' ';
            else return {};
        }else result+=ch;
    }
    return {};
}
std::uint16_t le16(const unsigned char *p){return static_cast<std::uint16_t>(p[0]|(p[1]<<8));}
std::uint32_t le32(const unsigned char *p){return std::uint32_t(p[0])|(std::uint32_t(p[1])<<8)|(std::uint32_t(p[2])<<16)|(std::uint32_t(p[3])<<24);}
NativeMeta parse_sfo(const std::string &path){
    const std::string bytes=small_file(path);
    if(bytes.size()<20 || bytes.compare(0,4,"\0PSF",4)!=0)return {};
    const auto *b=reinterpret_cast<const unsigned char *>(bytes.data());
    const std::uint32_t keys=le32(b+8),values=le32(b+12),count=le32(b+16);
    if(count>256 || 20+count*16>bytes.size() || keys>=bytes.size() || values>=bytes.size())return {};
    NativeMeta meta;
    for(std::uint32_t i=0;i<count;++i){
        const auto *entry=b+20+i*16;
        const std::uint32_t key_at=keys+le16(entry);
        const std::uint32_t length=le32(entry+4), value_at=values+le32(entry+12);
        if(key_at>=bytes.size()||value_at>=bytes.size()||length>bytes.size()-value_at||length>1024)continue;
        const std::size_t remain=bytes.size()-key_at;
        const char *key=reinterpret_cast<const char *>(b+key_at);
        if(std::memchr(key,0,remain)==nullptr)continue;
        const char *value=reinterpret_cast<const char *>(b+value_at);
        const auto *nul=static_cast<const char *>(std::memchr(value,0,length));
        const std::string result(value,nul?static_cast<std::size_t>(nul-value):length);
        if(std::strcmp(key,"TITLE")==0)meta.title=result;
        if(std::strcmp(key,"TITLE_ID")==0)meta.title_id=result;
    }
    return meta;
}
NativeMeta native_meta(const std::string &folder){
    const auto json=small_file(folder+"/sce_sys/param.json");
    NativeMeta result{json_field(json,"titleName"),json_field(json,"titleId")};
    if(result.title.empty() || result.title_id.empty()){
        const auto sfo=parse_sfo(folder+"/sce_sys/param.sfo");
        if(result.title.empty())result.title=sfo.title;
        if(result.title_id.empty())result.title_id=sfo.title_id;
    }
    if(result.title.empty() || result.title_id.empty()){
        const auto sfo=parse_sfo(folder+"/PS4_GAME/PARAM.SFO");
        if(result.title.empty())result.title=sfo.title;
        if(result.title_id.empty())result.title_id=sfo.title_id;
    }
    return result;
}
bool native_candidate(const std::string &folder){
    return is_file(folder+"/sce_sys/param.json") || is_file(folder+"/sce_sys/param.sfo") ||
        is_file(folder+"/PS4_GAME/PARAM.SFO") || is_file(folder+"/eboot.bin");
}
std::string guess_id(const std::string &folder) {
    auto b=basename(folder);auto lower=lowercase(b);
    if (b.size() >= 9 && (lower.compare(0,4,"ppsa")==0 || lower.compare(0,4,"cusa")==0)) {
        bool digits=true;for(int i=4;i<9;++i)if(b[i]<'0'||b[i]>'9')digits=false;
        if(digits)return b.substr(0,9);
    }
    return {};
}
std::string uid(const std::string &platform, const std::string &path) {
    // Stable FNV-1a 64-bit over platform, NUL delimiter, then original path.
    unsigned long long h=14695981039346656037ull;
    for (unsigned char c:platform){h^=c;h*=1099511628211ull;}
    h^=0;h*=1099511628211ull;
    for (unsigned char c:path){h^=c;h*=1099511628211ull;}
    const char *digits="0123456789abcdef"; std::string out(16,'0');
    for(int i=15;i>=0;--i){out[static_cast<std::size_t>(i)]=digits[h&15];h>>=4;}
    return out;
}
bool stfs_file(const std::string &path) {
    FILE *f=std::fopen(path.c_str(),"rb");if(!f)return false;
    char b[4]{};auto n=std::fread(b,1,4,f);std::fclose(f);
    return n==4 && (std::memcmp(b,"CON ",4)==0 || std::memcmp(b,"LIVE",4)==0 || std::memcmp(b,"PIRS",4)==0);
}
void append_game(Catalogue &out, std::set<std::pair<std::string,std::string>> &seen,
                 std::string platform,std::string path,std::string title,std::string format,
                 std::size_t maximum) {
    if(out.games.size()>=maximum){out.truncated=true;return;}
    if(!seen.insert({platform,path}).second)return;
    Game item;
    item.id=uid(platform,path);item.title=std::move(title);item.platform=std::move(platform);
    item.path=std::move(path);item.format=std::move(format);item.title_id=guess_id(item.path);
    item.cover_path=local_cover(item.path,item.format=="installationsordner",item.title_id);
    out.games.push_back(std::move(item));
}
void walk(const Root &root,const std::string &path,int level,int max_depth,std::size_t max_games,
          Catalogue &out,std::set<std::pair<std::string,std::string>> &seen) {
    if(out.truncated)return;
    DIR *d=opendir(path.c_str());
    if(!d){out.errors.push_back(path+": Lesefehler ("+std::to_string(errno)+")");return;}
    std::vector<Child> children;
    while(auto *item=readdir(d)) {
        std::string name=item->d_name;
        if(name=="." || name==".." || (!name.empty() && name[0]=='.'))continue;
        if(name.size()>255 || path.size()+name.size()+1>4096)continue;
        std::string child=path+(path.back()=='/'?"":"/")+name;
        struct stat st{};if(lstat(child.c_str(),&st)!=0)continue;
        if(!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode))continue;
        children.push_back({std::move(name),std::move(child),S_ISDIR(st.st_mode)});
    }
    closedir(d);
    std::sort(children.begin(),children.end(),[](const Child &a,const Child &b){return a.name<b.name;});
    bool native = (root.platform=="PS5/PS4" || root.platform=="PS5" || root.platform=="PS4");
    for(const auto &c:children){
        if (out.truncated) break;
        if(native) {
            if(c.folder && native_candidate(c.path)) {
                const auto meta=native_meta(c.path);
                std::string p=classify_native(c.path);
                if(meta.title_id.rfind("CUSA",0)==0)p="PS4";
                if(meta.title_id.rfind("PPSA",0)==0)p="PS5";
                if(p=="PS5/PS4" && root.platform!="PS5/PS4")p=root.platform;
                append_game(out,seen,p,c.path,meta.title.empty()?title_from(c.name):meta.title,"installationsordner",max_games);
                if(!out.games.empty() && out.games.back().path==c.path && !meta.title_id.empty())
                    out.games.back().title_id=meta.title_id;
            }else if(c.folder && level<max_depth)walk(root,c.path,level+1,max_depth,max_games,out,seen);
            continue;
        }
        if(c.folder){if(level<max_depth)walk(root,c.path,level+1,max_depth,max_games,out,seen);continue;}
        const std::string fmt=format_for(root.platform,c.name);
        if(!fmt.empty()) {
            if(root.platform=="PS1" && fmt=="cue") { /* one cue per disc */ }
            const std::string title=(root.platform=="Xbox 360" && lowercase(c.name)=="default.xex") ? title_from(basename(path)): title_from(c.name);
            append_game(out,seen,root.platform,c.path,title,fmt,max_games);
        }else if(root.platform=="Xbox 360" && extension(c.name).empty() && stfs_file(c.path)) {
            append_game(out,seen,root.platform,c.path,title_from(path==root.path?c.name:basename(path)),"STFS",max_games);
        }
    }
}
std::string escaped(const std::string &v){
    static const char *hex="0123456789abcdef";std::string out="\"";
    for(unsigned char c:v){if(c=='"'||c=='\\'){out+='\\';out+=static_cast<char>(c);}else if(c=='\n')out+="\\n";
        else if(c=='\r')out+="\\r";else if(c=='\t')out+="\\t";
        else if(c<32){out+="\\u00";out+=hex[c>>4];out+=hex[c&15];}else out+=static_cast<char>(c);
    }return out+'"';
}
} // namespace

std::vector<Root> load_roots(const std::string &config_path) {
    // Only known candidate paths; file parsing never modifies them.
    const Root defaults[]={
        {"PS5/PS4","/data/etaHEN/games"},
        {"PS2","/data/PCSX2/games"}, {"PS2","/mnt/usb1/PS5SX2/games"},
        {"PS2","/mnt/usb0/PS5SX2/games"}, {"Switch","/data/prosperoeden/roms"},
        {"Switch","/mnt/usb0/eden/roms"}, {"Switch","/mnt/usb1/eden/roms"},
        {"Xbox 360","/data/xbox360"},{"Xbox 360","/mnt/usb1/xbox360"},
        {"Xbox 360","/mnt/usb0/xbox360"}, {"Xbox 360","/data/homebrew/PPSA50011/assets/roms"}
    };
    FILE *f=std::fopen(config_path.c_str(),"rb");
    if(!f)return {std::begin(defaults),std::end(defaults)};
    std::vector<Root> roots;
    char line[8192];
    while(std::fgets(line,sizeof(line),f)){
        const std::size_t length=std::strlen(line);
        if(length==0 || length>4098 || line[0]=='#')continue;
        if(line[length-1]!='\n' && !std::feof(f)){
            // Oversized line; discard the remainder rather than parsing fragments.
            int c=0;while((c=std::fgetc(f))!=EOF && c!='\n'){}
            continue;
        }
        std::string entry(line);
        while(!entry.empty() && (entry.back()=='\n'||entry.back()=='\r'))entry.pop_back();
        const auto split=entry.find('|');if(split==std::string::npos)continue;
        Root r{entry.substr(0,split),entry.substr(split+1)};
        if(r.platform!="PS5/PS4"&&r.platform!="PS5"&&r.platform!="PS4"&&r.platform!="PS2"&&r.platform!="Switch"&&r.platform!="Xbox 360"&&r.platform!="PS1"&&r.platform!="PSP")continue;
        if(r.path.empty() || r.path[0]!='/' || r.path=="/" || r.path.find("/../")!=std::string::npos || ends(r.path,"/..") || r.path.size()>4096)continue;
        roots.push_back(std::move(r));
        if(roots.size()==128)break;
    }
    std::fclose(f);
    return roots;
}
Catalogue scan(const std::vector<Root> &roots,int max_depth,std::size_t max_games){
    Catalogue result;std::set<std::pair<std::string,std::string>> seen;
    max_depth=std::max(0,std::min(12,max_depth));max_games=std::min(std::size_t(10000),max_games);
    for(const auto &root:roots){
        if(root.path.empty() || root.path[0]!='/' || root.path=="/" || root.path.find("/../")!=std::string::npos || ends(root.path,"/..")){result.errors.push_back("Unzulaessiger Pfad: "+root.path);continue;}
        struct stat st{};
        if(lstat(root.path.c_str(),&st)!=0){
            const int err=errno;result.roots.push_back({root.platform,root.path,err==EACCES?"zugriff_verweigert":(err==ENOENT?"offline":"fehler")});continue;
        }
        if(!S_ISDIR(st.st_mode)){result.roots.push_back({root.platform,root.path,"fehler"});continue;}
        DIR *probe=opendir(root.path.c_str());
        if(!probe){result.roots.push_back({root.platform,root.path,errno==EACCES?"zugriff_verweigert":"fehler"});continue;}
        closedir(probe);
        result.roots.push_back({root.platform,root.path,"ok"});
        walk(root,root.path,0,max_depth,max_games,result,seen);
        if(result.truncated)break;
    }
    std::sort(result.games.begin(),result.games.end(),[](const Game &a,const Game &b){
        return lowercase(a.title)==lowercase(b.title)?a.platform<b.platform:lowercase(a.title)<lowercase(b.title);
    });
    return result;
}
void apply_cover_overrides(Catalogue &catalogue,const std::string &path){
    FILE *f=std::fopen(path.c_str(),"rb");if(!f)return;
    char line[8192];std::size_t lines=0;
    while(lines++<10000 && std::fgets(line,sizeof(line),f)){
        const std::size_t length=std::strlen(line);
        if(length<2 || length>=sizeof(line)-1 || line[0]=='#')continue;
        std::string entry(line);
        while(!entry.empty() && (entry.back()=='\n'||entry.back()=='\r'))entry.pop_back();
        const auto split=entry.find('|');if(split==std::string::npos)continue;
        const auto key=entry.substr(0,split),cover=entry.substr(split+1);
        if(cover.size()>4096||cover.empty()||cover[0]!='/'||!is_file(cover))continue;
        for(auto &g:catalogue.games)if(g.id==key || g.path==key)g.cover_path=cover;
    }
    std::fclose(f);
}
Catalogue merge_unavailable(Catalogue fresh, const Catalogue &previous) {
    std::set<std::string> known;
    for (const auto &g : fresh.games) known.insert(g.id);
    for (const auto &old : previous.games) {
        if (known.count(old.id)) continue;
        for (const auto &root : fresh.roots) {
            if (root.status == "ok") continue;
            if (old.path == root.path || (old.path.size() > root.path.size() &&
                 old.path.compare(0,root.path.size(),root.path) == 0 &&
                 old.path[root.path.size()] == '/')) {
                Game offline = old; offline.available = false;
                fresh.games.push_back(std::move(offline)); known.insert(old.id);
                break;
            }
        }
    }
    std::sort(fresh.games.begin(),fresh.games.end(),[](const Game &a,const Game &b){
        return lowercase(a.title)==lowercase(b.title)?a.platform<b.platform:lowercase(a.title)<lowercase(b.title);
    });
    return fresh;
}
bool write_json(const Catalogue &catalogue,const std::string &file){
    FILE *f=std::fopen(file.c_str(),"wb");if(!f)return false;
    auto put=[&](const std::string &text){return std::fwrite(text.data(),1,text.size(),f)==text.size();};
    bool ok=put("{\"schema\":4,\"scan_source\":\"native_posix_read_only\",\"games\":[");
    for(std::size_t i=0;i<catalogue.games.size() && ok;++i){
        const auto &g=catalogue.games[i];
        ok=put(std::string(i?",{":"{")+"\"id\":"+escaped(g.id)+",\"title\":"+escaped(g.title)
             +",\"platform\":"+escaped(g.platform)+",\"path\":"+escaped(g.path)
             +",\"format\":"+escaped(g.format)+",\"title_id\":"+escaped(g.title_id)
             +",\"cover_path\":"+escaped(g.cover_path)+",\"available\":"+(g.available?"true":"false")
             +",\"launch_status\":\"nicht_verifiziert\"}");
    }
    ok=ok&&put("],\"unavailable_paths\":[");bool first=true;
    for(const auto &r:catalogue.roots)if(r.status!="ok" && ok){
        ok=put(std::string(first?"{":",{")+"\"platform\":"+escaped(r.platform)+",\"path\":"+escaped(r.path)
             +",\"status\":"+escaped(r.status)+"}");first=false;
    }
    ok=ok&&put("],\"errors\":[");
    for(std::size_t i=0;i<catalogue.errors.size() && ok;++i)ok=put(std::string(i?",":"")+escaped(catalogue.errors[i]));
    ok=ok&&put(std::string("],\"truncated\":")+(catalogue.truncated?"true":"false")+"}\n");
    if(std::fclose(f)!=0)ok=false;
    return ok;
}
} // namespace ulg
