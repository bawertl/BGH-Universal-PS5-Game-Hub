# Aktueller GitHub-Build-Stand (14.10.2026)

**Wenn du die native PS5-Anwendung bauen lassen möchtest, lies zuerst `START_HIER_GITHUB.md`.** Der native GitHub-Workflow ist korrigiert und mit 32 Host-Tests geprüft. Ein **echter** PS5-Build wurde in dieser Umgebung noch nicht erreicht; der Runner auf GitHub muss ihn tatsächlich erzeugen. Nach einem grünen Workflow kann das überprüfte PS5-App-ZIP aus der Actions-Seite geladen werden. Keine Installation auf die PS5 ohne vorherige Prüfung der Title-ID.

---

# PS5 Universal Game Launcher – V0.5 (PS5 Buildvorbereitung)

**Projektstand 14. Oktober 2026.** Deutschsprachige Spielebibliothek für jailbroken PS5 mit Firmware 13.60 als Zielplattform. Kein Downloader, keine Spiele, keine Emulatoren, keine Systemmodifikation. Vorhandene Spieledateien, Savegames, etaHEN, kstuff, ShadowMountPlus und Payload-Autoload werden vom Projekt **nicht geändert**.

## Wichtig vorweg

Dieses Archiv enthält **vollständigen Quellcode des selbst entwickelten Launchers**, den vollständig auf Linux/x86-64 kompilierten und getesteten nativen **Quellcode** samt Tests und ein Skript zum Erstellen einer nativen PS5-App aus dem öffentlich verfügbaren **ps5-homebrew-ui**-SDK. Es enthält **noch KEIN auf der PS5 ausführbares `eboot.bin` oder installierbares PS5-Paket**. Die PS5-SDK- und OpenGL-Abhängigkeiten sind in dieser Entwicklungsumgebung nicht verfügbar und konnten wegen nicht verfügbarer externer Downloads hier nicht installiert werden. Ein erfolgreicher Firmware-13.60-Hardwaretest wurde **nicht durchgeführt**.

## Implementiert

- **Native grafische Oberfläche (PS5-Quellcode):** Dunkles Premium-Raster mit 6 Spalten, Plattformauswahl, Details, Favoriten, Suche per DualSense-Bildschirmtastatur, Ordnerstatus und manuelle Aktualisierung. Nutzt `blackbearreloaded/ps5-homebrew-ui`.
- **Plattformen:** PS5, PS4, PS2 (PS5SX2), Nintendo Switch (ProsperoEden), Xbox 360 (PS5X360); zusätzliche Scanpfade und PS1/PSP über die Konfiguration.
- **Native Dateisuche:** Read-only-POSIX-Zugriff, keine Symlink-Rekursion, harte Begrenzungen, Titel aus `param.json` bzw. PS4-`PARAM.SFO` sofern lesbar, Scan von ISO/CHD/CSO/ZSO, NSP/XCI, XEX, Xbox-360-STFS und nativen App-Ordnern (teilweise heuristisch). Keine Inhalts- oder Echtheitsprüfung der Spiele.
- **Cover:** Lokale PNG-Erkennung und tatsächlicher nativer PNG-Decoder mit GPU-Textur-Upload; bis zu 48 Texturen gleichzeitig im RAM, auf max. 512 Pixel pro Achse verkleinert. Ein falsches Cover kann per `assets/cover_overrides.conf` korrigiert werden. JPEG wird im Host-Browser angezeigt, **in der nativen UI noch nicht decodiert**; dort erscheint der Design-Fallback. Keine Web-Anfragen.
- **Persistenz:** Binärer Cache mit Begrenzung und Prüfsumme, Favoriten und angefragte Starts in der **eigenen** Titelablage `/download0/hui/ulg_v04/`; fehlende USB-Spielpfade bleiben nach Aktualisierung als offline markiert. Mit vorhandenem Cache schneller Start ohne kompletten Neuscan; Quadrat aktualisiert die Bibliothek vollständig.
- **Startanbindung:** ProsperoEden `--rom <Pfad> --exit-after-game` und PS5X360 mit absolutem Spielpfad; TCP-Protokoll des offenen PS5-Forwarder-Formats an **bereits laufenden** Dienst `127.0.0.1:10199`. Erst nach expliziter Aktion. Läuft kein solcher Dienst, wird ein Fehler angezeigt. Bei `queued` fordert die App systemkonformes Schließen über die öffentliche UI-Kit-Funktion an, damit der angefragte Start erfolgen kann. **Nur auf einem simulierten Host-Dienst geprüft, nicht auf PS5 13.60.**
- **Kein vorgetäuschter Start:** PS5SX2, native PS4/PS5-Titel und andere Plattformen zeigen explizit an, dass der Direktstart noch nicht nachgewiesen ist.

## DualSense-Bedienung (nativ implementiert, noch nicht an PS5 geprüft)

| Eingabe | Funktion |
| --- | --- |
| Steuerkreuz / linker Stick | Fokus bewegen |
| X | Details; in Details bestätigten Start anfragen; Suche Zeichen eingeben |
| Kreis | Zurück / Fenster schließen |
| L1 / R1 | Plattformfilter (UI-Kit-Shell wird für Single-Design modifiziert) |
| Dreieck | Suche öffnen; in Suche löschen; in Details Favorit |
| Quadrat | Bibliothek aktualisieren; in Suche löschen |
| Options | Einstellungen / Ordnerstatus |

## Repository-Struktur

- `native_ps5/` – native Bibliothek, Metadaten, Cache, PNG, Forwarder-Client, PS5-GUI-Quellcode und Linux-Testprogramme.
- `tooling/install_ui_kit_overlay.py` – kopiert den Launcher in einen **lokalen** Checkout des PS5 UI-Kits (mit Backups geänderter Originaldateien).
- `tooling/build_native_ps5.sh` – hostseitiges, versioniert gepinntes PS5-Buildskript inklusive Format-/Paketprüfung und ZIP-Erzeugung. **In dieser Umgebung ausgeführt, jedoch vor dem SDK-Build durch fehlende GitHub-DNS-Auflösung beendet.**
- `tooling/host_shim/` und `tooling/test_native_gui_syntax.sh` – Compile-only-Schnittstellenprüfung, **keine echte PS5-Toolchain**.
- `src/`, `ui/` – browserbasierte, lokale PC-Entwicklungsansicht samt Scanner und lokalem Cache; **keine native PS5-App**.
- `assets/paths.conf` – konfigurierbare native Scanpfade.
- `assets/cover_overrides.conf` – optionale manuelle Cover-Zuweisung.
- `tests/` – 25 automatisierte Hosttests; 3 neue Regressionstests für PNG-Priorität, wiederholbares Overlay und Build-Pipeline.

## Verifizierte Tests

Auf Linux mit Clang++ 17 / GCC werden die nativen Host-Komponenten mit `-std=c++20 -Wall -Wextra -Wpedantic -Werror` kompiliert. **25/25 automatisierte Tests bestanden**, darunter lokale Datei-/Cover-Erkennung, Format-/Protokollprüfung, USB-offline-Merge, beschädigte Cache-Dateien, ungültige PNGs, Metadaten und die UI-Host-Shim-Syntaxprüfung. Diese Ergebnisse sagen **nichts** über Firmware-13.60-Installation oder reale Spielstart-Kompatibilität aus.

```bash
make -C native_ps5
python3 -m pytest -q tests
bash tooling/test_native_gui_syntax.sh
./native_ps5/scanner-host --paths assets/paths.conf --covers assets/cover_overrides.conf --output /tmp/ulg-library.json
```

**PC-Entwicklungsansicht:** `python3 src/host_server.py` und `http://127.0.0.1:8765/` öffnen. Ohne eingebundene PS5-Spielordner sind null erkannte Spiele erwartbar. Mit einer an den PC angeschlossenen Testbibliothek `config/paths.json` anpassen. `tooling/start_host_preview.py` ist ein optionaler Starter (Python 3.10+).

## Nativen PS5-Build erstellen (Linux/WSL mit Internet und der dokumentierten Toolchain)

```bash
# Alles auf Entwicklungsrechner, NICHT auf der PS5!
bash tooling/build_native_ps5.sh
# Optional eine vorab als frei überprüfte App-ID:
# TITLE_ID=PPSA99079 bash tooling/build_native_ps5.sh
```

Das Skript holt den **auf Commit `bbe19054ee2e7ec069254775273aeb8846c4bd3e` gepinnten** Quellcode von `blackbearreloaded/ps5-homebrew-ui`, installiert unser Overlay im **Checkout auf dem Rechner**, initialisiert eine Entwicklungs-App-ID, bezieht SDK-Abhängigkeiten mit deren offiziellen Build-Skripten und ruft `make` auf. Ein resultierender Titelordner sollte unter `build/ps5/ps5-homebrew-ui/dist/<TITLE_ID>/` liegen und wird bei Erfolg zusätzlich als PS5-Test-ZIP unter `build/ps5/PS5_Universal_Game_Launcher_<TITLE_ID>_PS5_TEST.zip` verpackt. Der ZIP-Pfad wird **nur bei einem echten erfolgreichen nativen Build** erzeugt. **Ein solcher Ordner wird in diesem ZIP nicht vorgetäuscht.** `PPSA99079` ist nur ein Entwicklungsvorschlag, nicht auf deiner PS5 als frei geprüft. Niemals vor einer Kollisionsprüfung übertragen. Installation und mögliche Berechtigungsfreigaben siehe `docs/NATIVE_PS5.md`.

## Offene Punkte

1. Echter Build gegen die vollständigen SDKs/OpenGL-Bibliotheken sowie PS5-Firmware-13.60-Test.
2. Datei-Zugriffsrechte für fremde App-/USB-Spielordner. Ein funktionierender Jailbreak garantiert die Freigabe nicht; es wird **keine** Erhöhung von Rechten oder zusätzlicher Payload ausgelöst.
3. Startdienst 10199 auf deiner Konsole verifizieren; er ist nicht zwingend durch etaHEN oder PLK bereits vorhanden. Bei fehlendem Dienst wird nicht gestartet.
4. PS5SX2-Direktstart: Upstream-PR #25 ist bis zum Prüftag nicht als reguläre Release-Funktion belegt. Native PS5/PS4-Direktstarts nicht belegt.
5. Native JPEG/WebP-Cover, Online-Cover-Suche, automatische PS2-Serien-ID, besondere Xbox-360-Containerformate sowie Unicode-Schriftabdeckung durch UI-Kit bleiben offen.

**Lizenz:** Eigener Code unter MIT-Lizenz. Nach Integration in `ps5-homebrew-ui` gelten für die daraus entstandene gemeinsame Anwendung zusätzlich dessen GPL-3.0-or-later-Pflichten. Externe Bibliotheken/SDKs sind nicht im Archiv enthalten. Quellen und Kompatibilitätsnachweise siehe `docs/NATIVE_PS5.md`.

## V0.5: konkreter geprüfter Build-Blocker und automatisierter Alternativweg

Der erneute direkte PS5-Buildversuch am 14.10.2026 scheiterte bereits bei `git clone` mit `Could not resolve host: github.com`. Der Entwicklungscontainer ist netzwerkbeschränkt und besitzt weder den SDK-Checkout noch die nativen PS5-OpenGL-Bibliotheken. Eine Linux-ELF würde daran nichts ändern; eine gefälschte `eboot.bin` wird ausdrücklich nicht erstellt. Das vollständige Prüfprotokoll steht in `docs/BUILD_BLOCKER_2026-10-14.md`.

Für einen automatisierten **echten** PS5-Build liegt nun `.github/workflows/ps5-build.yml` bei. Eine GitHub-Actions-Umgebung mit Netzwerkzugriff kann dadurch selbst SDK und UI-Kit beschaffen, den Launcher bauen, dessen Paketstruktur prüfen und das resultierende ZIP als Artefakt bereitstellen. Dieses Workflow-Ergebnis wurde **nicht** durchgeführt oder behauptet; ohne ein Repository, in dem das Projekt und der Workflow ausgeführt werden dürfen, ist das nur ein reproduzierbarer Bauweg. Die Build-Pipeline wurde syntaktisch geprüft.

V0.5 beseitigt außerdem eine konkrete Cover-Erkennungslücke: Ein vorhandenes `.png` wird nun vor `.jpg/.jpeg` gewählt, die der native Decoder ohnehin noch nicht darstellen kann. Beim Start aus dem Cache prüft die native Anwendung den Mountpoint auch auf Verzeichnis-Lesbarkeit und markiert verschwundene Spiele als offline.

**Lizenzen:** Der eigens entwickelte Code steht unter MIT; beim kombinierten Bauen mit dem GPL-3.0-or-later UI-Kit müssen dessen GPL-Lizenz- und Quellcodepflichten eingehalten werden.
