#!/usr/bin/env bash
# PS5 Universal Game Launcher native build – development host only.
# No FTP, no console connection, no extra payloads, no firmware modifications.
set -euo pipefail
PROJECT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
OUT="${OUT:-$PROJECT/build/ps5}"
KIT="${KIT_DIR:-$OUT/ps5-homebrew-ui}"
TITLE_ID="${TITLE_ID:-PPSA99079}"
# SDK-independent pin of the actual UI kit reviewed in this project.
KIT_COMMIT="${KIT_COMMIT:-bbe19054ee2e7ec069254775273aeb8846c4bd3e}"
if [[ ! $TITLE_ID =~ ^PPSA[0-9]{5}$ ]]; then
  printf 'ERROR: TITLE_ID muss PPSA und fünf Ziffern enthalten.\n' >&2; exit 2
fi
for binary in git make python3 clang++ llvm-ar llvm-ranlib ld.lld unzip zip; do
  if ! command -v "$binary" >/dev/null 2>&1; then
    printf 'BLOCKER: Build-Werkzeug fehlt: %s\n' "$binary" >&2; exit 4
  fi
done
mkdir -p "$OUT"
if [[ ! -f "$KIT/Makefile" ]]; then
  if [[ -n ${KIT_DIR:-} ]]; then
    printf 'BLOCKER: KIT_DIR zeigt auf keinen vollständigen UI-Kit-Checkout: %s\n' "$KIT" >&2; exit 5
  fi
  printf 'Quelle herunterladen: https://github.com/blackbearreloaded/ps5-homebrew-ui\n'
  git clone --filter=blob:none https://github.com/blackbearreloaded/ps5-homebrew-ui.git "$KIT"
fi
if [[ -d "$KIT/.git" ]]; then
  if ! git -C "$KIT" cat-file -e "$KIT_COMMIT^{commit}" 2>/dev/null; then
    git -C "$KIT" fetch --depth=1 origin "$KIT_COMMIT"
  fi
  git -C "$KIT" checkout --detach "$KIT_COMMIT"
  actual=$(git -C "$KIT" rev-parse HEAD)
  if [[ $actual != "$KIT_COMMIT" ]]; then
    printf 'BLOCKER: Unerwarteter UI-Kit-Stand: %s\n' "$actual" >&2;exit 6
  fi
elif [[ ${ALLOW_UNVERIFIED_KIT:-0} == 1 ]]; then
  printf 'WARNUNG: Nicht verifizierter UI-Kit-Checkout: nur für lokale Simulation, kein Release.\n' >&2
else
  printf 'BLOCKER: UI-Kit ohne Git-Checkout; Commit nicht verifizierbar.\n' >&2
  exit 6
fi
python3 "$PROJECT/tooling/install_ui_kit_overlay.py" "$KIT"
make -C "$KIT" init TITLE_ID="$TITLE_ID" APP_NAME='Universal Game Launcher'
# Upstream make fetches the versioned SDK, creates libc.prx, links and packages.
make -C "$KIT" BUILD_JOBS="${BUILD_JOBS:-4}" app
PACKAGE="$KIT/dist/$TITLE_ID"
for file in 'eboot.bin' 'sce_module/libc.prx' 'sce_sys/param.json'; do
  if [[ ! -s "$PACKAGE/$file" ]]; then
    printf 'BLOCKER: Native PS5-Datei fehlt/ist leer: %s\n' "$PACKAGE/$file" >&2;exit 7
  fi
done
if ! grep -Fq '"titleId": "'"$TITLE_ID"'"' "$PACKAGE/sce_sys/param.json"; then
  printf 'BLOCKER: App-Metadaten enthalten falsche Titel-ID.\n' >&2;exit 8
fi
if [[ ! -f "$PACKAGE/assets/paths.conf" ]]; then
  printf 'BLOCKER: Scanpfad-Konfiguration wurde nicht paketiert.\n' >&2;exit 9
fi
# Crucial: DO NOT repack with zip. The upstream PS5 kit fixes every ZIP entry's
# 0777 permissions with zip-open-modes.py (required by ShadowMountPlus/native loader).
# A second generic zip -r silently loses that guarantee.
SOURCE_ZIP="$KIT/dist/$TITLE_ID.zip"
DEST="$OUT/PS5_Universal_Game_Launcher_V0_6_${TITLE_ID}_PS5_TEST.zip"
python3 "$PROJECT/tooling/verify_ps5_package.py" "$SOURCE_ZIP" "$TITLE_ID"
cp -f -- "$SOURCE_ZIP" "$DEST"
python3 "$PROJECT/tooling/verify_ps5_package.py" "$DEST" "$TITLE_ID"
(cd "$OUT" && sha256sum "${DEST##*/}" > "${DEST##*/}.sha256")
printf '\nNATIVER PS5-BUILD ERFOLGREICH: %s\n' "$DEST"
printf 'PS5-KONSOLENTEST: NOCH NICHT DURCHGEFÜHRT. Keine automatische Installation.\n'
