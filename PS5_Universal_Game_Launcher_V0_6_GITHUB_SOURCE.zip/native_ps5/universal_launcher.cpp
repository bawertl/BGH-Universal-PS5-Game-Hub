// PS5 Universal Game Launcher - UI component for blackbearreloaded/ps5-homebrew-ui.
// SPDX-License-Identifier: MIT
// Launch requests occur ONLY after explicit DualSense confirmation; no elevation or registration.
// To integrate, run tooling/install_ui_kit_overlay.py against a local checkout of ps5-homebrew-ui.
#include "concepts/concepts.hpp"
#include "concepts/library_core.hpp"
#include "concepts/root_manager.hpp"
#include "concepts/ftp_scan.hpp"
#include "concepts/state_store.hpp"
#include "concepts/cover_png.hpp"
#include "concepts/launcher_client.hpp"
#include "ui/glyphs.hpp"
#include "platform/ps5/system.hpp"
#include "ui/motion.hpp"
#include <algorithm>
#include <array>
#include <map>
#include <deque>
#include <cstdint>
#include <GL/glcorearb.h>
#include <cerrno>
#include <dirent.h>
#include <sys/types.h>
#include <cstdio>
#include <cstring>
#include <set>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace hui::concepts {
namespace {
using gfx::Color;
using gfx::Rect;
const Color kInk = Color::rgb(0xEDF1FF);
const Color kMuted = Color::rgb(0x9AA6BE);
const Color kAccent = Color::rgb(0x859AFF);
constexpr std::array<const char *,8> kPlatforms={
    "PS5/PS4","PS5","PS4","PS2","Switch","Xbox 360","PS1","PSP"
};
constexpr const char *kPathKeys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/_-.<+";
constexpr int kColumns = 6;
constexpr int kRows = 2;
constexpr int kPageSize = kColumns * kRows;
constexpr float kLeft = 82.0f;
constexpr float kTop = 332.0f;
constexpr float kCardW = 247.0f;
constexpr float kCardH = 265.0f;
constexpr float kGapX = 38.0f;
constexpr float kGapY = 27.0f;
constexpr std::array<const char *, 8> kTabs = {
    "Alle Spiele", "PS5", "PS4", "PS2", "Switch", "Xbox 360", "Favoriten", "Zuletzt gestartet"
};
constexpr const char *kTechniques[] = {
    "Lokaler POSIX-Scan ohne Schreibzugriff auf Spieleordner",
    "Native OpenGL-GUI mit DualSense und Plattformfiltern",
    "Spielstart erfolgt ausschliesslich nach expliziter Aktion und nur via vorhandenen Forwarder-Dienst"
};
std::string shorten(const std::string &s, std::size_t limit) {
    if(s.size() <= limit)return s;
    if(limit<4)return s.substr(0,limit);
    return s.substr(0,limit-3)+"...";
}
Color platform_color(const std::string &p){
    if(p=="PS5")return Color::rgb(0x4D6FFF);
    if(p=="PS4")return Color::rgb(0x4C91D8);
    if(p=="PS2")return Color::rgb(0xA182FD);
    if(p=="Switch")return Color::rgb(0xED646B);
    if(p=="Xbox 360")return Color::rgb(0x62C09A);
    return Color::rgb(0x7985A9);
}
class CoverTextures {
public:
    // Called only from update() while a GL context is current; draw() performs no file I/O.
    void load(const std::string &path) {
        if(path.empty() || textures_.count(path)) return;
        std::uint32_t texture = 0;
        if(path.size()>4 && path.substr(path.size()-4)==".png") {
            ulg::PngImage image;
            if(ulg::decode_png(path,image)) {
                GLuint gl_id=0;
                glGenTextures(1,&gl_id);
                if(gl_id){
                    glBindTexture(GL_TEXTURE_2D,gl_id);
                    glPixelStorei(GL_UNPACK_ALIGNMENT,4);
                    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,image.width,image.height,0,GL_RGBA,GL_UNSIGNED_BYTE,image.rgba.data());
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAX_LEVEL,0);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
                    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
                    texture=gl_id;
                }
            }
        }
        if(order_.size()>=48){
            const auto previous=order_.front();order_.pop_front();
            const GLuint old=static_cast<GLuint>(textures_[previous]);
            if(old)glDeleteTextures(1,&old);
            textures_.erase(previous);
        }
        textures_[path]=texture;order_.push_back(path);
    }
    bool has(const std::string &path) const {return textures_.count(path)>0;}
    std::uint32_t get(const std::string &path) const {
        const auto it=textures_.find(path);
        return it==textures_.end()?0:it->second;
    }
    void clear(){
        for(const auto &item:textures_){const GLuint texture=static_cast<GLuint>(item.second);if(texture)glDeleteTextures(1,&texture);}
        textures_.clear();order_.clear();
    }
    ~CoverTextures(){clear();}
private:
    std::map<std::string,std::uint32_t> textures_;
    std::deque<std::string> order_;
};
class UniversalLauncher final : public app::Concept {
public:
    explicit UniversalLauncher(app::Context &context) : context_(context) {
        // All writes are restricted to this title's own storage, never game directories.
        (void)mkdir("/download0/hui",0700);
        (void)mkdir(kStateFolder,0700);
        roots_=ulg::configured_roots(kUserPathsFile,"/app0/assets/paths.conf");
        ulg::Preferences preferences;
        if(ulg::read_preferences(kPrefsFile,preferences)){
            favorites_=std::move(preferences.favorites);
            recent_list_=std::move(preferences.recent);
        }
        for(const auto &id:recent_list_)recent_.insert(id);
        if(!ulg::read_catalogue_cache(kCacheFile,catalogue_))refresh();
        else{
            // Probe again without recursing. Cache must not hide removed USB drives.
            bool needs_ftp_reprobe=false;
            for(const auto &root:catalogue_.roots)if(root.status=="ftp_ok")needs_ftp_reprobe=true;
            if(catalogue_.roots.size()!=roots_.size() || catalogue_.failed_operations>0 || needs_ftp_reprobe)refresh();
            else {validate_cached_roots();
            ulg::apply_cover_overrides(catalogue_,"/app0/assets/cover_overrides.conf");
            rebuild();}
        }
    }
    const app::ConceptInfo &info() const override {
        static const app::ConceptInfo kInfo{
            "universal_launcher", "Universal Game Launcher",
            "Deine Spiele. Eine Bibliothek. Komplett lokal.",
            "src/concepts/universal_launcher.cpp", audio::SoundSet::glass, kAccent, kTechniques
        };
        return kInfo;
    }
    void enter() override { clock_=0.0f; }
    void update(const InputFrame &input, float dt, app::Feedback &feedback) override {
        clock_ += dt;
        load_next_visible_cover();
        if(input.is_pressed(Action::back)){
            if(path_editor_open_){path_editor_open_=false;feedback.play(audio::Cue::back);}
            else if(browser_open_){browser_open_=false;feedback.play(audio::Cue::back);}
            else if(search_open_){search_open_=false;feedback.play(audio::Cue::back);}
            else if(detail_ || settings_){detail_=false;settings_=false;feedback.play(audio::Cue::back);}
            return;
        }
        if(input.is_pressed(Action::menu)){
            detail_=false;search_open_=false;browser_open_=false;path_editor_open_=false;
            settings_=!settings_;feedback.play(audio::Cue::open);return;
        }
        if(search_open_){update_search(input,feedback);return;}
        if(path_editor_open_){update_path_editor(input,feedback);return;}
        if(browser_open_){update_browser(input,feedback);return;}
        if(settings_){update_settings(input,feedback);return;}
        if(detail_){
            if(input.is_pressed(Action::north))toggle_favorite();
            if(input.is_pressed(Action::confirm) && !indices_.empty()){
                const auto &g=catalogue_.games[indices_[static_cast<std::size_t>(selected_)]];
                const auto plan=ulg::make_launch_plan(g.platform,g.path);
                if(!g.available){launch_message_="USB-Laufwerk / Spiel nicht verfügbar";feedback.play(audio::Cue::error);}
                else if(!plan.supported){launch_message_=plan.reason;feedback.play(audio::Cue::error);}
                else {
                    struct stat current{};
                    if((!g.via_ftp && lstat(g.path.c_str(),&current)!=0) ||
                       (!g.via_ftp && !S_ISREG(current.st_mode) && !S_ISDIR(current.st_mode))){
                        launch_message_="Spiel / USB-Datentraeger nicht mehr verfuegbar";
                        feedback.play(audio::Cue::error);
                    }else{
                        const auto result=ulg::send_launch(plan);
                        launch_message_=result.message;
                        if(result.status==ulg::LaunchStatus::queued || result.status==ulg::LaunchStatus::started){
                            record_recent(g.id);feedback.play(audio::Cue::launch);
                            if(result.status==ulg::LaunchStatus::queued)sys::quit();
                        }else feedback.play(audio::Cue::error);
                    }
                }
            }
            return;
        }
        if(input.is_pressed(Action::page_prev)){tab_=tab_==0?static_cast<int>(kTabs.size()-1):tab_-1;rebuild();feedback.play(audio::Cue::tab);}
        if(input.is_pressed(Action::page_next)){tab_=(tab_+1)%static_cast<int>(kTabs.size());rebuild();feedback.play(audio::Cue::tab);}
        if(input.is_pressed(Action::west)){refresh();feedback.play(audio::Cue::select);}
        if(input.is_pressed(Action::north)){
            search_open_=true;search_key_=0;feedback.play(audio::Cue::open);return;
        }
        if(input.nav!=Direction::none && !indices_.empty()) {
            int candidate=selected_;
            switch(input.nav){
                case Direction::left: candidate-=1;break;
                case Direction::right: candidate+=1;break;
                case Direction::up: candidate-=kColumns;break;
                case Direction::down: candidate+=kColumns;break;
                default: break;
            }
            candidate=std::clamp(candidate,0,static_cast<int>(indices_.size()-1));
            if(candidate!=selected_){selected_=candidate;feedback.play(audio::Cue::focus);}
        }
        if(input.is_pressed(Action::confirm) && !indices_.empty()){
            detail_=true;launch_message_.clear();feedback.play(audio::Cue::open);
        }
    }
    void draw(app::Frame &frame) const override {
        frame.backdrop.mode=gfx::BackdropMode::aurora;
        frame.backdrop.colors[0]=Color::rgb(0x070B13);
        frame.backdrop.colors[1]=Color::rgb(0x151931);
        frame.backdrop.colors[2]=Color::rgb(0x1D2252);
        frame.backdrop.colors[3]=Color::rgb(0x37255F);
        frame.backdrop.time=clock_;
        auto &list=frame.scene;
        const auto &fonts=context_.fonts;
        list.rounded_rect({52,40,1816,110},28,Color::rgb(0x161D2D,0.93f));
        list.rounded_rect({76,69,9,52},4,kAccent);
        ui::text(list,fonts.semibold,"UNIVERSAL GAME LAUNCHER",105,100,33,kInk);
        ui::text(list,fonts.regular,"PS5  /  LOKALE BIBLIOTHEK",105,130,20,kMuted);
        ui::text(list,fonts.semibold,"V0.6 DIAGNOSE / ORDNER",1430,107,18,kAccent);
        for (int i=0;i<static_cast<int>(kTabs.size());++i) {
            const float x=80 + i*216;
            list.rounded_rect({x,170,202,53},16,i==tab_?Color::rgb(0x5665AF,0.75f):Color::rgb(0x252B3F,0.65f));
            ui::text(list,fonts.semibold,kTabs[static_cast<std::size_t>(i)],x+15,204,19,i==tab_?kInk:kMuted);
        }
        std::string counter=std::to_string(indices_.size())+" Spiele";
        ui::text(list,fonts.display,"Meine Spielebibliothek",83,292,45,kInk);
        if(!search_query_.empty())ui::text(list,fonts.regular,"Suche: "+shorten(search_query_,24),720,292,23,kAccent);
        ui::text(list,fonts.semibold,counter,1660,286,23,kAccent);
        if(indices_.empty()){
            list.rounded_rect({82,338,1753,510},30,Color::rgb(0x1C2334,0.85f));
            ui::text(list,fonts.display,"Keine Spiele angezeigt",140,470,46,kInk);
            ui::text(list,fonts.regular,"Quadrat: Ordner erneut pruefen  |  OPTIONS: Pfadstatus",140,524,26,kMuted);
        } else {
            int page=selected_/kPageSize;
            std::size_t first=static_cast<std::size_t>(page*kPageSize);
            std::size_t last=std::min(first+kPageSize,indices_.size());
            for(std::size_t j=first;j<last;++j)draw_card(list,catalogue_.games[indices_[j]],static_cast<int>(j-first),static_cast<int>(j)==selected_);
            std::string pagination="Seite "+std::to_string(page+1)+" / "+std::to_string((indices_.size()+kPageSize-1)/kPageSize);
            ui::text(list,fonts.regular,pagination,1450,944,20,kMuted);
        }
        list.rounded_rect({70,970,1780,76},22,Color::rgb(0x11192A,0.91f));
        const ui::Hint hints[]={
            {ui::Button::cross,"Details"},{ui::Button::circle,"Zurueck"},
            {ui::Button::l1,"Plattform",ui::Button::r1},
            {ui::Button::square,"Aktualisieren"},{ui::Button::triangle,"Suche"},
            {ui::Button::options,"Einstellungen"}
        };
        ui::HintLayout hint_layout;hint_layout.cy=1009;hint_layout.size=28;hint_layout.text_size=19;hint_layout.item_gap=34;
        ui::draw_hints(list,fonts,ui::GlyphStyle::dark(),hints,6,109,false,hint_layout);
        if(detail_)draw_detail(frame);
        if(settings_)draw_settings(frame);
        if(browser_open_)draw_browser(frame);
        if(path_editor_open_)draw_path_editor(frame);
        if(search_open_)draw_search(frame);
    }
private:
    static constexpr const char *kStateFolder="/download0/hui/ulg_v04";
    static constexpr const char *kCacheFile="/download0/hui/ulg_v04/library_v06.bin";
    static constexpr const char *kUserPathsFile="/download0/hui/ulg_v04/paths.user.conf";
    static constexpr const char *kPrefsFile="/download0/hui/ulg_v04/preferences.bin";
    void save_prefs(){
        ulg::Preferences pref;pref.favorites=favorites_;pref.recent=recent_list_;
        (void)ulg::write_preferences(pref,kPrefsFile);
    }
    void record_recent(const std::string &id){
        recent_list_.erase(std::remove(recent_list_.begin(),recent_list_.end(),id),recent_list_.end());
        recent_list_.insert(recent_list_.begin(),id);
        if(recent_list_.size()>80)recent_list_.resize(80);
        recent_.insert(id);save_prefs();
    }
    void validate_cached_roots(){
        for(std::size_t i=0;i<catalogue_.roots.size();++i){
            catalogue_.roots[i]=ulg::probe_root(roots_[i]);
        }
        catalogue_.failed_operations=0;catalogue_.failed_roots=0;catalogue_.disabled_roots=0;
        for(const auto &root:catalogue_.roots){
            if(root.status=="deaktiviert")++catalogue_.disabled_roots;
            else if(root.status!="ok"){
                ++catalogue_.failed_roots;++catalogue_.failed_operations;
            }
        }
        for(auto &g:catalogue_.games){
            struct stat game_stat{};
            g.available=g.via_ftp || (lstat(g.path.c_str(),&game_stat)==0 &&
                (S_ISREG(game_stat.st_mode)||S_ISDIR(game_stat.st_mode)));
            for(const auto &r:catalogue_.roots){
                if(r.status!="ok" && r.status!="ftp_ok" && g.path.size()>r.path.size() &&
                   g.path.compare(0,r.path.size(),r.path)==0 && g.path[r.path.size()]=='/'){
                    g.available=false;break;
                }
            }
        }
    }
    void load_next_visible_cover(){
        if(indices_.empty())return;
        const std::size_t page=static_cast<std::size_t>(selected_/kPageSize);
        const std::size_t first=page*kPageSize;
        for(std::size_t i=first;i<std::min(first+kPageSize,indices_.size());++i){
            const auto &g=catalogue_.games[indices_[i]];
            if(g.available && !g.cover_path.empty() && !covers_.has(g.cover_path)){
                covers_.load(g.cover_path);break; // at most one picture each update
            }
        }
    }
    void refresh() {
        const std::string selected_id=(!indices_.empty() && selected_<static_cast<int>(indices_.size())) ?
            catalogue_.games[indices_[static_cast<std::size_t>(selected_)]].id : "";
        auto fresh=ulg::scan(roots_,5,5000);
        // Existing localhost ftpsrv is an optional read-only fallback; no payload started.
        ulg::supplement_from_local_ftp(fresh,roots_,5,5000);
        catalogue_=ulg::merge_unavailable(std::move(fresh),catalogue_);
        ulg::apply_cover_overrides(catalogue_,"/app0/assets/cover_overrides.conf");
        (void)ulg::write_catalogue_cache(catalogue_,kCacheFile);
        covers_.clear();
        ++refresh_count_;rebuild();
        if(!selected_id.empty())for(std::size_t i=0;i<indices_.size();++i)
            if(catalogue_.games[indices_[i]].id==selected_id){selected_=static_cast<int>(i);break;}
    }
    static constexpr const char *kSearchKeys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 <-";
    void update_search(const InputFrame &input,app::Feedback &feedback){
        constexpr int columns=9;
        const int count=static_cast<int>(std::strlen(kSearchKeys));
        int next=search_key_;
        if(input.nav==Direction::left)next-=1;
        if(input.nav==Direction::right)next+=1;
        if(input.nav==Direction::up)next-=columns;
        if(input.nav==Direction::down)next+=columns;
        next=std::clamp(next,0,count-1);
        if(next!=search_key_){search_key_=next;feedback.play(audio::Cue::focus);}
        if(input.is_pressed(Action::west) || input.is_pressed(Action::north)){
            if(!search_query_.empty())search_query_.pop_back();rebuild();
        }
        if(input.is_pressed(Action::confirm)){
            const char key=kSearchKeys[search_key_];
            if(key=='<'){if(!search_query_.empty())search_query_.pop_back();}
            else if(key=='-'){search_open_=false;}
            else if(search_query_.size()<48)search_query_+=key;
            rebuild();feedback.play(audio::Cue::select);
        }
    }
    void draw_search(app::Frame &frame) const {
        frame.glass=true;
        auto &list=frame.overlay;const auto &fonts=context_.fonts;
        list.rounded_rect({327,160,1268,754},32,Color::rgb(0x151D2D,0.98f));
        ui::text(list,fonts.display,"Spiele suchen",385,245,45,kInk);
        list.rounded_rect({385,277,1150,80},16,Color::rgb(0x26314C));
        ui::text(list,fonts.semibold,search_query_.empty()?"Titel eingeben ...":search_query_,415,328,31,kInk);
        const int count=static_cast<int>(std::strlen(kSearchKeys));
        for(int i=0;i<count;++i){
            const int col=i%9,row=i/9;
            const float x=391+col*126.0f,y=395+row*95.0f;
            list.rounded_rect({x,y,109,74},13,i==search_key_?Color::rgb(0x596DBA):Color::rgb(0x273146));
            const char letter=kSearchKeys[i];
            std::string caption=letter==' '?"LEER":(letter=='<'?"LOESCHEN":(letter=='-'?"FERTIG":std::string(1,letter)));
            ui::text(list,fonts.semibold,caption,x+13,y+48,letter==' '||letter=='<'||letter=='-'?16:27,kInk);
        }
        ui::text(list,fonts.regular,"X: Buchstabe    Dreieck: Loeschen    Kreis: Fertig",400,867,22,kMuted);
    }
    void rebuild(){
        indices_.clear();
        for(std::size_t i=0;i<catalogue_.games.size();++i){
            const auto &g=catalogue_.games[i];
            bool show=tab_==0 || (tab_>=1 && tab_<=5 && g.platform==kTabs[static_cast<std::size_t>(tab_)]) ||
                      (tab_==6 && favorites_.count(g.id)>0) || (tab_==7 && recent_.count(g.id)>0);
            if(show && !search_query_.empty()){
                auto name=g.title;
                for(char &c:name)if(c>='a' && c<='z')c=static_cast<char>(c-'a'+'A');
                show=name.find(search_query_)!=std::string::npos;
            }
            if(show)indices_.push_back(i);
        }
        if(indices_.empty())selected_=0;
        else selected_=std::clamp(selected_,0,static_cast<int>(indices_.size()-1));
    }
    void toggle_favorite(){
        if(indices_.empty())return;
        auto &id=catalogue_.games[indices_[static_cast<std::size_t>(selected_)]].id;
        if(!favorites_.insert(id).second)favorites_.erase(id);
        save_prefs();rebuild();
    }
    void draw_card(gfx::DrawList &list,const ulg::Game &game,int index,bool selected) const {
        const auto &fonts=context_.fonts;
        const int col=index%kColumns,row=index/kColumns;
        const float x=kLeft+col*(kCardW+kGapX),y=kTop+row*(kCardH+kGapY);
        const auto accent=platform_color(game.platform);
        if(selected)list.glow({x-5,y-5,kCardW+10,kCardH+10},23,23,Color::rgb(0x7796FF,0.47f));
        list.rounded_rect({x,y,kCardW,kCardH},18,selected?Color::rgb(0x4D6097):Color::rgb(0x1C2638));
        const auto cover=covers_.get(game.cover_path);
        if(cover && game.available)list.image(cover,{x+4,y+4,kCardW-8,kCardH-8},gfx::kFullUv,Color::rgb(0xFFFFFF),15);
        else{
            list.gradient_rect({x+5,y+5,kCardW-10,kCardH-10},16,Color::rgb(0x172342),accent.with_alpha(0.55f));
            ui::text(list,fonts.display,game.platform,x+22,y+111,35,kInk);
            ui::text(list,fonts.regular,"KEIN LOKALES COVER",x+20,y+155,14,kMuted);
        }
        list.rounded_rect({x+5,y+kCardH-83,kCardW-10,78},12,Color::rgb(0x0B1020,0.92f));
        ui::text(list,fonts.semibold,shorten(game.title,22),x+19,y+kCardH-46,20,kInk);
        ui::text(list,fonts.regular,game.available?game.platform:"USB OFFLINE",x+19,y+kCardH-18,16,game.available?accent:Color::rgb(0xFFAC86));
        if(favorites_.count(game.id))list.star(x+kCardW-28,y+27,12,Color::rgb(0xFFE3A0));
        if(selected)list.bordered_rect({x,y,kCardW,kCardH},18,Color::rgb(0xFFFFFF,0.0f),4,kAccent);
    }
    void draw_detail(app::Frame &frame) const {
        auto &list=frame.overlay;const auto &fonts=context_.fonts;
        if(indices_.empty())return;
        const auto &g=catalogue_.games[indices_[static_cast<std::size_t>(selected_)]];
        frame.glass=true;
        list.rounded_rect({265,125,1390,790},36,Color::rgb(0x151D2D,0.97f));
        list.rounded_rect({315,186,350,525},28,Color::rgb(0x26314C));
        list.rounded_rect({345,215,137,50},16,platform_color(g.platform));
        ui::text(list,fonts.semibold,g.platform,359,251,29,Color::rgb(0xFFFFFF));
        const auto cover=covers_.get(g.cover_path);
        if(cover && g.available)list.image(cover,{320,192,340,513},gfx::kFullUv,Color::rgb(0xFFFFFF),22);
        else{
            ui::text(list,fonts.display,"COVER",354,516,57,kMuted);
            ui::text(list,fonts.regular,"Kein PNG-Cover gefunden",344,653,21,kMuted);
        }
        ui::text(list,fonts.display,shorten(g.title,35),710,244,43,kInk);
        ui::text(list,fonts.semibold,"Plattform: "+g.platform,710,309,27,kAccent);
        ui::text(list,fonts.regular,"Format: "+g.format,710,353,23,kMuted);
        ui::text(list,fonts.regular,"Spielpfad:",710,401,23,kMuted);
        ui::text(list,fonts.regular,shorten(g.path,78),710,436,20,kInk);
        const auto plan=ulg::make_launch_plan(g.platform,g.path);
        const bool can_start=plan.supported && g.available;
        list.rounded_rect({711,506,800,125},20,can_start?Color::rgb(0x3D527C):Color::rgb(0x2C3044));
        ui::text(list,fonts.semibold,can_start?"X  SPIEL STARTEN":(g.available?"DIREKTSTART NICHT VERFUEGBAR":"SPIEL NICHT VERFUEGBAR"),740,559,27,can_start?kInk:kMuted);
        ui::text(list,fonts.regular,can_start?"Vorhandener PS5-Startdienst erforderlich":(g.available?plan.reason:"Datentraeger erneut anschliessen"),740,599,20,Color::rgb(0xFFB982));
        if(!launch_message_.empty())ui::text(list,fonts.regular,shorten(launch_message_,90),714,684,22,kAccent);
        ui::text(list,fonts.regular,"Dreieck: Favorit   |   Kreis: Zurueck",720,736,23,kMuted);
    }
    void set_message(std::string message){settings_message_=std::move(message);}
    void save_roots_and_rescan(){
        if(!ulg::save_user_roots(roots_,kUserPathsFile)){
            set_message("SPEICHERFEHLER: Persoenliche Pfade konnten nicht gespeichert werden.");
            return;
        }
        refresh();set_message("Gespeichert und erneut gescannt.");
    }
    void change_add_platform(int direction){
        const int count=static_cast<int>(kPlatforms.size());
        add_platform_=(add_platform_+count+direction)%count;
    }
    void update_settings(const InputFrame &input,app::Feedback &feedback){
        if(input.is_pressed(Action::page_prev))change_add_platform(-1);
        if(input.is_pressed(Action::page_next))change_add_platform(1);
        const int count=static_cast<int>(roots_.size());
        if(input.nav==Direction::up && count>0)settings_selected_=std::max(0,settings_selected_-1);
        if(input.nav==Direction::down && count>0)settings_selected_=std::min(count-1,settings_selected_+1);
        if(input.is_pressed(Action::west)){refresh();set_message("Alle aktiven Ordner erneut gescannt.");feedback.play(audio::Cue::select);}
        if(input.is_pressed(Action::confirm) && count>0){
            roots_[static_cast<std::size_t>(settings_selected_)].enabled=
                !roots_[static_cast<std::size_t>(settings_selected_)].enabled;
            save_roots_and_rescan();feedback.play(audio::Cue::select);
        }
        if(input.is_pressed(Action::north)){
            browser_open_=true;browser_path_="/";browser_selected_=0;refresh_browser();
            feedback.play(audio::Cue::open);
        }
        if(input.is_pressed(Action::touch)){
            if(count>0){
                edited_root_=settings_selected_;
                input_path_=roots_[static_cast<std::size_t>(settings_selected_)].path;
                for(std::size_t i=0;i<kPlatforms.size();++i)
                    if(roots_[static_cast<std::size_t>(settings_selected_)].platform==kPlatforms[i])
                        add_platform_=static_cast<int>(i);
            }else {edited_root_=-1;input_path_="/";}
            path_key_=0;path_editor_open_=true;feedback.play(audio::Cue::open);
        }
    }
    void refresh_browser(){browser_=ulg::browse_folders(browser_path_);browser_selected_=0;}
    void add_root_path(const std::string &path){
        ulg::Root candidate{kPlatforms[static_cast<std::size_t>(add_platform_)],path};
        if(!ulg::valid_root(candidate)){set_message("Ungueltiger Pfad (absolute Ordner ohne .. erforderlich).");return;}
        for(std::size_t i=0;i<roots_.size();++i){
            if(static_cast<int>(i)==edited_root_)continue;
            if(roots_[i].path==candidate.path && roots_[i].platform==candidate.platform){
                set_message("Dieser Ordner ist fuer die Plattform bereits vorhanden.");return;
            }
        }
        if(edited_root_>=0 && static_cast<std::size_t>(edited_root_)<roots_.size()){
            candidate.enabled=roots_[static_cast<std::size_t>(edited_root_)].enabled;
            roots_[static_cast<std::size_t>(edited_root_)]=std::move(candidate);
        }else if(roots_.size()<128){
            roots_.push_back(std::move(candidate));settings_selected_=static_cast<int>(roots_.size()-1);
        }else {set_message("Maximal 128 Ordner moeglich.");return;}
        save_roots_and_rescan();browser_open_=false;path_editor_open_=false;
    }
    void update_browser(const InputFrame &input,app::Feedback &feedback){
        if(input.is_pressed(Action::page_prev))change_add_platform(-1);
        if(input.is_pressed(Action::page_next))change_add_platform(1);
        const int count=static_cast<int>(browser_.entries.size());
        if(input.nav==Direction::up && count>0)browser_selected_=std::max(0,browser_selected_-1);
        if(input.nav==Direction::down && count>0)browser_selected_=std::min(count-1,browser_selected_+1);
        if(input.is_pressed(Action::confirm) && count>0){
            browser_path_=browser_.entries[static_cast<std::size_t>(browser_selected_)].path;
            refresh_browser();feedback.play(audio::Cue::select);
        }
        if(input.is_pressed(Action::west)){
            // Only the directory currently displayed is selected, never a game file.
            edited_root_=-1;add_root_path(browser_path_);feedback.play(audio::Cue::select);
        }
        if(input.is_pressed(Action::touch)){
            const auto end=browser_path_.find_last_of('/');
            browser_path_=end==0?"/":browser_path_.substr(0,end);
            refresh_browser();feedback.play(audio::Cue::focus);
        }
        if(input.is_pressed(Action::north)){
            edited_root_=-1;input_path_=browser_path_=="/"?"/":browser_path_+"/";
            path_key_=0;path_editor_open_=true;feedback.play(audio::Cue::open);
        }
    }
    void update_path_editor(const InputFrame &input,app::Feedback &feedback){
        constexpr int columns=9;
        const int count=static_cast<int>(std::strlen(kPathKeys));
        int next=path_key_;
        if(input.nav==Direction::left)next--;
        if(input.nav==Direction::right)next++;
        if(input.nav==Direction::up)next-=columns;
        if(input.nav==Direction::down)next+=columns;
        next=std::clamp(next,0,count-1);
        if(next!=path_key_){path_key_=next;feedback.play(audio::Cue::focus);}
        if(input.is_pressed(Action::west) && input_path_.size()>1)input_path_.pop_back();
        if(input.is_pressed(Action::north))path_uppercase_=!path_uppercase_;
        if(input.is_pressed(Action::confirm)){
            char key=kPathKeys[path_key_];
            if(key=='<'){if(input_path_.size()>1)input_path_.pop_back();}
            else if(key=='+'){add_root_path(input_path_);}
            else if(input_path_.size()<240){
                if(key>='A'&&key<='Z'&&!path_uppercase_)key=static_cast<char>(key-'A'+'a');
                input_path_+=key;
            }
            feedback.play(audio::Cue::select);
        }
    }
    std::string state_label(const ulg::RootState &root) const {
        if(root.status=="ok")return "OK";
        if(root.status=="ftp_ok")return "FTP lesbar";
        if(root.status=="deaktiviert")return "AUS";
        if(root.status=="usb_offline")return "USB unsichtbar";
        if(root.status=="offline")return "nicht sichtbar";
        if(root.status=="zugriff_verweigert")return "Zugriff verweigert";
        if(root.status=="kein_ordner")return "kein Ordner";
        return "Fehler";
    }
    void draw_settings(app::Frame &frame) const {
        frame.glass=true;
        auto &list=frame.overlay;const auto &fonts=context_.fonts;
        list.rounded_rect({128,62,1664,963},30,Color::rgb(0x151D2D,0.98f));
        ui::text(list,fonts.display,"Einstellungen / Spieleordner",185,143,43,kInk);
        ui::text(list,fonts.regular,"POSIX errno oder lokal per FTP gelesen (ftpsrv 2121). Kein Jailbreak-Eingriff.",185,188,21,kMuted);
        ui::text(list,fonts.semibold,std::string("Neue Plattform: ")+kPlatforms[static_cast<std::size_t>(add_platform_)] + " (L1/R1)",189,227,22,kAccent);
        constexpr int visible=11;
        const int first=std::max(0,settings_selected_-visible+1);
        for(int i=first;i<static_cast<int>(roots_.size()) && i<first+visible;++i){
            const float y=260+static_cast<float>(i-first)*52;
            const auto &root=roots_[static_cast<std::size_t>(i)];
            const ulg::RootState state=i<static_cast<int>(catalogue_.roots.size()) ?
                catalogue_.roots[static_cast<std::size_t>(i)] : ulg::probe_root(root);
            const bool selected=i==settings_selected_;
            list.rounded_rect({182,y,1548,50},12,selected?Color::rgb(0x475D8F):Color::rgb(0x242E42));
            ui::text(list,fonts.semibold,root.platform,195,y+32,18,platform_color(root.platform));
            ui::text(list,fonts.regular,shorten(root.path,46),360,y+32,17,kInk);
            ui::text(list,fonts.semibold,state_label(state),1030,y+31,17,(state.status=="ok"||state.status=="ftp_ok")?Color::rgb(0x8ADDAC):Color::rgb(0xF6B17C));
            const auto error=state.error_code==0?(state.status=="ftp_ok"?"FTP MLSD":"--"):
                (std::to_string(state.error_code)+" / "+state.operation);
            ui::text(list,fonts.regular,shorten(error,23),1350,y+31,16,kMuted);
        }
        if(roots_.size()>visible)ui::text(list,fonts.regular,"Ordner "+std::to_string(settings_selected_+1)+" / "+std::to_string(roots_.size()),1540,902,18,kMuted);
        const auto failure_count=catalogue_.failed_operations;
        const std::string summary="Fehlversuche: "+std::to_string(failure_count)+"  |  Hauptpfade: "+
            std::to_string(catalogue_.failed_roots)+"  |  Deaktiviert: "+std::to_string(catalogue_.disabled_roots);
        ui::text(list,fonts.regular,summary,190,899,23,kInk);
        ui::text(list,fonts.regular,"X: Ein/Aus  |  Quadrat: Scan  |  Dreieck: Browser  |  Touchpad: Pfad bearbeiten",189,945,20,kAccent);
        ui::text(list,fonts.regular,"Kreis/OPTIONS: Schliessen",189,983,20,kMuted);
        if(!settings_message_.empty())ui::text(list,fonts.semibold,shorten(settings_message_,93),185,858,20,Color::rgb(0xFFC18D));
    }
    void draw_browser(app::Frame &frame) const {
        frame.glass=true;auto &list=frame.overlay;const auto &fonts=context_.fonts;
        list.rounded_rect({260,118,1400,828},35,Color::rgb(0x121A2C,0.99f));
        ui::text(list,fonts.display,"Ordnerbrowser (nur lesend)",313,208,40,kInk);
        ui::text(list,fonts.semibold,shorten(browser_path_,75),311,270,22,kAccent);
        ui::text(list,fonts.regular,std::string("Plattform: ")+kPlatforms[static_cast<std::size_t>(add_platform_)],311,312,22,kMuted);
        if(browser_.state.status!="ok" && browser_.state.status!="ftp_ok"){
            ui::text(list,fonts.semibold,"Verzeichnis kann nicht gelesen werden",315,402,27,Color::rgb(0xF6B17C));
            ui::text(list,fonts.regular,"POSIX "+browser_.state.operation+" errno="+std::to_string(browser_.state.error_code),315,442,24,kMuted);
            ui::text(list,fonts.regular,"Dreieck: Pfad mit Bildschirmtastatur eingeben",315,492,21,kAccent);
        }else if(browser_.entries.empty())ui::text(list,fonts.semibold,"Keine Unterordner vorhanden",315,403,25,kMuted);
        else {
            constexpr int visible=10;
            const int first=std::max(0,browser_selected_-visible+1);
            for(int i=first;i<static_cast<int>(browser_.entries.size()) && i<first+visible;++i){
                const float y=342+static_cast<float>(i-first)*49;
                list.rounded_rect({311,y,1276,45},11,i==browser_selected_?Color::rgb(0x51629F):Color::rgb(0x242E42));
                ui::text(list,fonts.regular,shorten(browser_.entries[static_cast<std::size_t>(i)].name,65),334,y+30,22,kInk);
            }
        }
        ui::text(list,fonts.regular,"X: Ordner oeffnen  |  Quadrat: Hier hinzufuegen  |  Touchpad: Hoch",311,867,20,kAccent);
        ui::text(list,fonts.regular,"Dreieck: Pfad eingeben  |  L1/R1: Plattform  |  Kreis: Zurueck",311,909,19,kMuted);
    }
    void draw_path_editor(app::Frame &frame) const {
        frame.glass=true;auto &list=frame.overlay;const auto &fonts=context_.fonts;
        list.rounded_rect({267,93,1386,899},32,Color::rgb(0x111A2D,0.99f));
        ui::text(list,fonts.display,edited_root_>=0?"Spielpfad bearbeiten":"Spielpfad hinzufuegen",328,166,39,kInk);
        ui::text(list,fonts.regular,"Plattform: "+std::string(kPlatforms[static_cast<std::size_t>(add_platform_)]),332,212,23,kAccent);
        list.rounded_rect({321,235,1255,100},12,Color::rgb(0x26314C));
        ui::text(list,fonts.semibold,shorten(input_path_,79),342,294,23,kInk);
        ui::text(list,fonts.regular,path_uppercase_?"GROSSBUCHSTABEN":"kleinbuchstaben",1300,361,20,kAccent);
        const int count=static_cast<int>(std::strlen(kPathKeys));
        for(int i=0;i<count;++i){
            const int col=i%9,row=i/9;
            const float x=325+col*139.0f,y=399+row*91.0f;
            list.rounded_rect({x,y,125,79},12,i==path_key_?Color::rgb(0x647BC1):Color::rgb(0x27344C));
            char letter=kPathKeys[i];
            std::string label;
            if(letter=='<')label="LOESCH";
            else if(letter=='+')label="FERTIG";
            else {if(letter>='A'&&letter<='Z'&&!path_uppercase_)letter=static_cast<char>(letter-'A'+'a');label=letter;}
            ui::text(list,fonts.semibold,label,x+17,y+49,label.size()>1?17:29,kInk);
        }
        ui::text(list,fonts.regular,"X: Zeichen  |  Quadrat: Loeschen  |  Dreieck: Gross/Klein  |  Kreis: Zurueck",324,948,19,kMuted);
    }
    app::Context &context_;
    ulg::Catalogue catalogue_;
    std::vector<ulg::Root> roots_;
    ulg::BrowserResult browser_;
    std::string browser_path_="/",input_path_="/",settings_message_;
    int settings_selected_=0,add_platform_=3,browser_selected_=0,path_key_=0,edited_root_=-1;
    bool browser_open_=false,path_editor_open_=false,path_uppercase_=false;
    std::vector<std::size_t> indices_;
    std::set<std::string> favorites_;
    std::set<std::string> recent_;
    std::vector<std::string> recent_list_;
    CoverTextures covers_;
    float clock_=0;
    int tab_=0,selected_=0,refresh_count_=0;
    bool detail_=false,settings_=false,search_open_=false;
    std::string search_query_;
    int search_key_=0;
    std::string launch_message_;
};
} // namespace
std::unique_ptr<app::Concept> make_universal_launcher(app::Context &context) {
    return std::make_unique<UniversalLauncher>(context);
}
} // namespace hui::concepts
