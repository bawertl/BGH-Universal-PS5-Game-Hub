// PS5 Universal Game Launcher - optional read-only loopback ftpsrv access.
// No STOR/DELE/RMD/MKD, no payload start; only localhost:2121 by default.
// SPDX-License-Identifier: MIT
#pragma once
#include <cstddef>
#include <string>
#include <vector>
namespace ulg {
struct FtpEntry {std::string name;bool folder=false;};
struct FtpListing {
    bool ok=false;
    int reply=0; // FTP response, NOT errno
    std::string operation;
    std::vector<FtpEntry> entries;
};
class FtpReadonly {
public:
    explicit FtpReadonly(int port=2121);
    ~FtpReadonly();
    FtpReadonly(const FtpReadonly&)=delete;
    FtpReadonly& operator=(const FtpReadonly&)=delete;
    bool connect_local();
    FtpListing list(const std::string &directory,std::size_t max_entries=2000);
    bool retrieve(const std::string &path,std::string &bytes,std::size_t max_bytes=262144);
    bool connected() const {return fd_>=0;}
private:
    int fd_=-1;
    int port_=2121;
    std::string pending_;
    int response(std::string &line);
    int command(const std::string &line,std::string &reply);
    int data_socket(std::string &error);
    bool read_data(int data,std::string &out,std::size_t max_size);
};
} // namespace ulg
