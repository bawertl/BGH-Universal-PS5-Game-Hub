// Local test runner only. Does not initiate any launch without command-line arguments.
// SPDX-License-Identifier: MIT
#include "launcher_client.hpp"
#include <iostream>
#include <string>
int main(int argc, char **argv) {
    if(argc != 4) {std::cerr<<"usage: launch-test-cli PLATFORM PATH PORT\n";return 2;}
    ulg::LaunchPlan p=ulg::make_launch_plan(argv[1],argv[2]);
    auto result=ulg::send_launch(p,static_cast<unsigned short>(std::stoi(argv[3])));
    std::cout<<static_cast<int>(result.status)<<"|"<<result.message<<"\n";
    return 0;
}
