// SPDX-License-Identifier: MIT
#include "ftp_scan.hpp"
#include "ftp_readonly.hpp"
#include <algorithm>
#include <cctype>
#include <set>
#include <string>
#include <utility>

namespace ulg {
namespace {
bool begins(const std::string &s,const std::string &p){return s.compare(0,p.size(),p)==0;}
bool ends_ci(const std::string &s,const std::string &extension){
    if(s.size()<extension.size())return false;
    for(std::size_t i=0;i<extension.size();++i){
        const unsigned char c=static_cast<unsigned char>(s[s.size()-extension.size()+i]);
        if(std::tolower(c)!=extension[i])return false;
    }
    return true;
}
std::string suffix(const std::string &s){const auto pos=s.find_last_of('/');return pos==std::string::npos?s:s.substr(pos+1);}
std::string title_from_name(std::string s){
    const auto dot=s.find_last_of('.');if(dot!=std::string::npos && s.size()-dot<=5)s.resize(dot);
    for(char &c:s)if(c=='_'||c=='.')c=' ';
    return s.empty()?"Unbenanntes Spiel":s;
}
std::string platform_from_path(const std::string &path,const std::string &fallback){
    const auto name=suffix(path);
    if(name.size()>=4){
        if(begins(name,"PPSA"))return "PS5";
        if(begins(name,"CUSA"))return "PS4";
    }
    return fallback;
}
std::string format_for_file(const std::string &platform,const std::string &name){
    if(platform=="PS2")for(const char *e:{".iso",".chd",".cso",".zso"})if(ends_ci(name,e))return e+1;
    if(platform=="Switch")for(const char *e:{".nsp",".xci"})if(ends_ci(name,e))return e+1;
    if(platform=="Xbox 360"){
        if(ends_ci(name,".iso"))return "iso";
        if(ends_ci(name,"default.xex"))return "xex";
    }
    if(platform=="PS1")for(const char *e:{".cue",".chd"})if(ends_ci(name,e))return e+1;
    if(platform=="PSP")for(const char *e:{".iso",".cso",".chd",".pbp"})if(ends_ci(name,e))return e+1;
    return {};
}
std::string stable_id(const std::string &platform,const std::string &path){
    unsigned long long h=14695981039346656037ull;
    for(unsigned char c:platform){h^=c;h*=1099511628211ull;}
    h^=0;h*=1099511628211ull;
    for(unsigned char c:path){h^=c;h*=1099511628211ull;}
    std::string out(16,'0');const char *hex="0123456789abcdef";
    for(int i=15;i>=0;--i){out[static_cast<std::size_t>(i)]=hex[h&15];h>>=4;}
    return out;
}
void append_game(Catalogue &out,std::set<std::string> &seen,const std::string &platform,
                 const std::string &path,const std::string &title,const std::string &format,
                 std::size_t max_games){
    if(out.games.size()>=max_games){out.truncated=true;return;}
    const std::string id=stable_id(platform,path);
    if(!seen.insert(id).second)return;
    Game item;item.id=id;item.title=title;item.platform=platform;item.path=path;
    item.format=format;item.available=true;item.via_ftp=true;
    const auto name=suffix(path);
    if(name.size()>=9&&(begins(name,"PPSA")||begins(name,"CUSA")))item.title_id=name.substr(0,9);
    out.games.push_back(std::move(item));
}
void ftp_walk(FtpReadonly &ftp,const Root &root,const std::string &path,int level,
              int max_depth,std::size_t max_games,Catalogue &catalogue,
              std::set<std::string>&seen,std::size_t &budget){
    if(catalogue.truncated || budget==0)return;
    --budget;
    const auto listing=ftp.list(path);
    if(!listing.ok){
        ++catalogue.failed_operations;
        if(catalogue.errors.size()<256)catalogue.errors.push_back(
            listing.operation+" (FTP="+std::to_string(listing.reply)+") "+path);
        return;
    }
    const bool native=root.platform=="PS5/PS4"||root.platform=="PS4"||root.platform=="PS5";
    for(const auto &entry:listing.entries){
        if(catalogue.truncated)break;
        if(entry.name.empty()||entry.name[0]=='.')continue;
        const std::string child=path+(path=="/"?"":"/")+entry.name;
        if(child.size()>4000)continue;
        if(native){
            if(!entry.folder)continue;
            const auto inner=ftp.list(child);
            bool is_app=false;
            if(inner.ok){
                for(const auto &it:inner.entries)
                    if(!it.folder && it.name=="eboot.bin")is_app=true;
                if(!is_app)for(const auto &it:inner.entries)if(it.folder && it.name=="sce_sys")is_app=true;
            }
            if(is_app){
                append_game(catalogue,seen,platform_from_path(child,root.platform),child,
                            title_from_name(entry.name),"installationsordner",max_games);
            }else if(level<max_depth)ftp_walk(ftp,root,child,level+1,max_depth,max_games,catalogue,seen,budget);
            continue;
        }
        if(entry.folder){
            if(level<max_depth)ftp_walk(ftp,root,child,level+1,max_depth,max_games,catalogue,seen,budget);
        }else{
            const std::string fmt=format_for_file(root.platform,entry.name);
            if(!fmt.empty())append_game(catalogue,seen,root.platform,child,
                (root.platform=="Xbox 360"&&ends_ci(entry.name,"default.xex"))?
                    title_from_name(suffix(path)):title_from_name(entry.name),fmt,max_games);
        }
    }
}
}
void supplement_from_local_ftp(Catalogue &catalogue,const std::vector<Root> &roots,
                               int max_depth,std::size_t max_games,int port){
    bool need=false;
    for(const auto &r:catalogue.roots)if(r.status!="ok"&&r.status!="deaktiviert"){need=true;break;}
    if(!need)return;
    FtpReadonly ftp(port);
    if(!ftp.connect_local())return;
    std::set<std::string> seen;for(const auto &g:catalogue.games)seen.insert(g.id);
    std::size_t budget=500;
    const std::size_t count=std::min(roots.size(),catalogue.roots.size());
    for(std::size_t i=0;i<count;++i){
        if(!roots[i].enabled || catalogue.roots[i].status=="ok")continue;
        const auto listing=ftp.list(roots[i].path,1200);
        if(!listing.ok)continue;
        catalogue.roots[i]={roots[i].platform,roots[i].path,"ftp_ok",0,"FTP MLSD"};
        if(catalogue.failed_roots>0)--catalogue.failed_roots;
        if(catalogue.failed_operations>0)--catalogue.failed_operations;
        // The failed POSIX probe was recovered through FTP and is no longer counted.
        for(auto it=catalogue.errors.begin();it!=catalogue.errors.end();++it){
            if(it->size()>=roots[i].path.size() &&
               it->compare(it->size()-roots[i].path.size(),roots[i].path.size(),roots[i].path)==0){
                catalogue.errors.erase(it);break;
            }
        }
        // Scan content recursively. CWD/MLSD are read-only FTP commands.
        ftp_walk(ftp,roots[i],roots[i].path,0,max_depth,max_games,catalogue,seen,budget);
        if(catalogue.truncated || budget==0)break;
    }
    std::sort(catalogue.games.begin(),catalogue.games.end(),[](const Game &a,const Game &b){
        return a.title==b.title?a.platform<b.platform:a.title<b.title;
    });
}
} // namespace ulg
