// Protocol: heydemoura/ps5-forwarder-format SPEC.md section 7 (GPL project; independent client).
// SPDX-License-Identifier: MIT
#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace ulg {
enum class LaunchStatus { started, queued, no_launcher, refused, invalid_target, invalid_path, protocol_error };
struct LaunchPlan {
    std::string target;
    std::vector<std::string> argv;
    std::string reason;
    bool supported = false;
};
struct LaunchResponse {
    LaunchStatus status = LaunchStatus::protocol_error;
    std::uint32_t stage = 0;
    std::uint32_t rc1 = 0;
    std::uint32_t rc2 = 0;
    std::string message;
};
// Only documented targets. PS5SX2/PS5/PS4 intentionally excluded.
LaunchPlan make_launch_plan(const std::string &platform, const std::string &game_path);
// Caller initiated only, never automatically invoked by scanning or app startup.
// Needs an already running loopback launcher; NEVER injects ELF or changes system state.
LaunchResponse send_launch(const LaunchPlan &plan, unsigned short port = 10199);
} // namespace ulg
