// SPDX-License-Identifier: MIT
#include "state_store.hpp"
#include <cstdint>
#include <cstdio>
#include <limits>
#include <string>
#include <vector>

namespace ulg { namespace {
constexpr std::size_t kMaxFile = 16 * 1024 * 1024;
constexpr std::size_t kMaxField = 4096;
struct Writer {
    std::string bytes;
    void number(std::uint32_t n) {
        for (int i=0;i<4;++i) bytes.push_back(static_cast<char>(n >> (8*i)));
    }
    void str(const std::string &s) {
        number(static_cast<std::uint32_t>(s.size())); bytes.append(s);
    }
};
struct Reader {
    const std::string &bytes;
    std::size_t pos = 0;
    bool good = true;
    std::uint32_t number() {
        if (!good || pos>bytes.size() || bytes.size()-pos<4) {good=false;return 0;}
        std::uint32_t n=0;
        for(int i=0;i<4;++i) n|=static_cast<std::uint32_t>(static_cast<unsigned char>(bytes[pos++]))<<(8*i);
        return n;
    }
    std::string str() {
        const std::uint32_t len=number();
        if (!good || len>kMaxField || pos>bytes.size() || len>bytes.size()-pos) {good=false;return {};}
        std::string result=bytes.substr(pos,len);pos+=len;return result;
    }
};
std::uint32_t checksum(const std::string &data) {
    std::uint32_t h=2166136261u;
    for (unsigned char c : data) {h^=c;h*=16777619u;}
    return h;
}
bool save(const std::string &path, const std::string &magic, Writer &w) {
    if (path.empty() || path.size()>4000 || w.bytes.size()>kMaxFile-8) return false;
    std::string complete=magic+w.bytes;
    Writer tail;tail.number(checksum(complete));complete+=tail.bytes;
    const std::string temporary=path+".tmp";
    FILE *output=std::fopen(temporary.c_str(),"wb");
    if(!output)return false;
    bool ok=std::fwrite(complete.data(),1,complete.size(),output)==complete.size();
    if(std::fflush(output)!=0)ok=false;
    if(std::fclose(output)!=0)ok=false;
    if(!ok){std::remove(temporary.c_str());return false;}
    if(std::rename(temporary.c_str(),path.c_str())!=0){std::remove(temporary.c_str());return false;}
    return true;
}
bool load(const std::string &path, const std::string &magic, std::string &bytes) {
    FILE *in=std::fopen(path.c_str(),"rb");if(!in)return false;
    if(std::fseek(in,0,SEEK_END)!=0){std::fclose(in);return false;}
    const long size=std::ftell(in);
    if(size<static_cast<long>(magic.size()+4) || size>static_cast<long>(kMaxFile) ||
       std::fseek(in,0,SEEK_SET)!=0){std::fclose(in);return false;}
    std::string full(static_cast<std::size_t>(size),'\0');
    const bool ok=std::fread(full.data(),1,full.size(),in)==full.size();
    std::fclose(in);if(!ok)return false;
    if(full.compare(0,magic.size(),magic)!=0)return false;
    const std::size_t position=full.size()-4;
    std::uint32_t stored=0;
    for(int i=0;i<4;++i)stored|=static_cast<std::uint32_t>(static_cast<unsigned char>(full[position+i]))<<(8*i);
    full.resize(position);
    if(checksum(full)!=stored)return false;
    bytes=full.substr(magic.size());return true;
}
} // namespace
bool write_catalogue_cache(const Catalogue &catalogue,const std::string &path){
    Writer w;w.number(static_cast<std::uint32_t>(catalogue.games.size()));
    for(const auto &g:catalogue.games){
        for(const auto *s:{&g.id,&g.title,&g.platform,&g.path,&g.format,&g.title_id,&g.cover_path}){
            if(s->size()>kMaxField)return false;
            w.str(*s);
        }
        w.number(g.available?1u:0u);
        w.number(g.via_ftp?1u:0u);
    }
    w.number(static_cast<std::uint32_t>(catalogue.roots.size()));
    for(const auto &r:catalogue.roots){
        for(const auto *field:{&r.platform,&r.path,&r.status,&r.operation}){
            if(field->size()>kMaxField)return false;
            w.str(*field);
        }
        w.number(static_cast<std::uint32_t>(r.error_code));
    }
    w.number(static_cast<std::uint32_t>(catalogue.failed_operations));
    w.number(static_cast<std::uint32_t>(catalogue.failed_roots));
    w.number(static_cast<std::uint32_t>(catalogue.disabled_roots));
    return save(path,"ULG6",w);
}
bool read_catalogue_cache(const std::string &path,Catalogue &out){
    std::string bytes;if(!load(path,"ULG6",bytes))return false;
    Reader r{bytes};Catalogue next;
    const auto count=r.number();if(count>10000)return false;
    for(std::uint32_t i=0;i<count && r.good;++i){
        Game g;g.id=r.str();g.title=r.str();g.platform=r.str();g.path=r.str();
        g.format=r.str();g.title_id=r.str();g.cover_path=r.str();g.available=r.number()==1;
        g.via_ftp=r.number()==1;
        if(g.path.empty() || g.path[0]!='/' || g.id.empty())return false;
        next.games.push_back(std::move(g));
    }
    const auto roots=r.number();if(roots>128)return false;
    for(std::uint32_t i=0;i<roots && r.good;++i){
        RootState s;s.platform=r.str();s.path=r.str();s.status=r.str();s.operation=r.str();
        s.error_code=static_cast<int>(r.number());next.roots.push_back(std::move(s));
    }
    next.failed_operations=r.number();next.failed_roots=r.number();next.disabled_roots=r.number();
    if(next.failed_roots>next.failed_operations || next.failed_operations>1000000)return false;
    if(!r.good || r.pos!=bytes.size())return false;
    out=std::move(next);return true;
}
bool write_preferences(const Preferences &prefs,const std::string &path){
    if(prefs.favorites.size()>10000 || prefs.recent.size()>256)return false;
    Writer w;w.number(static_cast<std::uint32_t>(prefs.favorites.size()));
    for(const auto &id:prefs.favorites){if(id.size()>kMaxField)return false;w.str(id);}
    w.number(static_cast<std::uint32_t>(prefs.recent.size()));
    for(const auto &id:prefs.recent){if(id.size()>kMaxField)return false;w.str(id);}
    return save(path,"ULGP",w);
}
bool read_preferences(const std::string &path,Preferences &out){
    std::string bytes;if(!load(path,"ULGP",bytes))return false;
    Reader r{bytes};Preferences prefs;
    const auto count=r.number();if(count>10000)return false;
    for(std::uint32_t i=0;i<count && r.good;++i)prefs.favorites.insert(r.str());
    const auto recent=r.number();if(recent>256)return false;
    for(std::uint32_t i=0;i<recent && r.good;++i)prefs.recent.push_back(r.str());
    if(!r.good || r.pos!=bytes.size())return false;
    out=std::move(prefs);return true;
}
} // namespace ulg
