// SPDX-License-Identifier: MIT
// Minimal protocol client, no sockets opened until the user explicitly requests a launch.
#include "launcher_client.hpp"
#include <arpa/inet.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <netinet/in.h>
#include <string>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
namespace ulg {
namespace {
constexpr std::size_t kPacket=0x1020;
constexpr std::uint32_t kMagic=0x4C574650u;
void put_u32(unsigned char *p,std::uint32_t v){for(int i=0;i<4;++i)p[i]=static_cast<unsigned char>((v>>(i*8))&0xFF);}
std::uint32_t get_u32(const unsigned char *p){return std::uint32_t(p[0]) | (std::uint32_t(p[1])<<8) | (std::uint32_t(p[2])<<16) | (std::uint32_t(p[3])<<24);}
bool write_full(int fd,const unsigned char *data,std::size_t n){
    while(n){const ssize_t written=send(fd,data,n,0);if(written<0 && errno==EINTR)continue;
        if(written<=0)return false;
        data+=written;n-=static_cast<std::size_t>(written);
    }return true;
}
bool read_full(int fd,unsigned char *data,std::size_t n){
    while(n){const ssize_t got=recv(fd,data,n,0);if(got<0&&errno==EINTR)continue;
        if(got<=0)return false;
        data+=got;n-=static_cast<std::size_t>(got);
    }return true;
}
bool suffix(const std::string &name,const std::string &ext){
    if(name.size()<ext.size())return false;
    for(std::size_t i=0;i<ext.size();++i){char a=name[name.size()-ext.size()+i],b=ext[i];
        if(a>='A'&&a<='Z') a=static_cast<char>(a+'a'-'A');
        if(a!=b)return false;
    }return true;
}
} // namespace
LaunchPlan make_launch_plan(const std::string &platform,const std::string &game_path){
    LaunchPlan p;
    if(game_path.empty()||game_path.front()!='/'||game_path.size()>4000||game_path.find("/../")!=std::string::npos||game_path.find('\0')!=std::string::npos){
        p.reason="Ungültiger Spielpfad";return p;
    }
    if(platform=="Switch"){
        if(!suffix(game_path,".nsp")&&!suffix(game_path,".xci")){p.reason="Kein bestätigtes Switch-Format";return p;}
        p.target="PPSA99008";p.argv={"--rom",game_path,"--exit-after-game"};p.supported=true;
    }else if(platform=="Xbox 360"){
        p.target="PPSA50011";p.argv={game_path};p.supported=true;
    }else p.reason="Für diese Plattform keine verifizierte Startschnittstelle";
    return p;
}
LaunchResponse send_launch(const LaunchPlan &plan,unsigned short port){
    LaunchResponse response;
    if(!plan.supported||plan.target.size()!=9){response.status=LaunchStatus::invalid_target;response.message="Start nicht unterstützt";return response;}
    if(plan.argv.size()>64){response.status=LaunchStatus::invalid_path;response.message="Zu viele Argumente";return response;}
    unsigned char req[kPacket]{};
    put_u32(req,kMagic);put_u32(req+4,1);
    std::memcpy(req+8,plan.target.data(),9);
    std::size_t used=0;
    for(const auto &arg:plan.argv){
        if(arg.find('\0')!=std::string::npos||used+arg.size()+1>4096){response.status=LaunchStatus::invalid_path;response.message="Argument zu lang";return response;}
        std::memcpy(req+0x20+used,arg.data(),arg.size());used+=arg.size()+1;
    }
    put_u32(req+0x18,static_cast<std::uint32_t>(plan.argv.size()));
    put_u32(req+0x1C,static_cast<std::uint32_t>(used));
    const int fd=socket(AF_INET,SOCK_STREAM,0);
    if(fd<0){response.status=LaunchStatus::no_launcher;response.message="Socket nicht verfügbar";return response;}
    timeval timeout{};timeout.tv_sec=1;timeout.tv_usec=0;
    setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    sockaddr_in address{};address.sin_family=AF_INET;address.sin_port=htons(port);address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
    if(connect(fd,reinterpret_cast<sockaddr *>(&address),sizeof(address))!=0){
        close(fd);response.status=LaunchStatus::no_launcher;response.message="Kein Startdienst auf 127.0.0.1";return response;
    }
    unsigned char reply[0x18]{};
    const bool ok=write_full(fd,req,sizeof(req))&&read_full(fd,reply,sizeof(reply));
    close(fd);
    if(!ok||get_u32(reply)!=kMagic||get_u32(reply+4)!=1){
        response.status=LaunchStatus::protocol_error;response.message="Ungültige Antwort des Startdienstes";return response;
    }
    response.stage=get_u32(reply+8);response.rc1=get_u32(reply+0x0C);response.rc2=get_u32(reply+0x10);
    if(response.stage==0){response.status=LaunchStatus::started;response.message="Spielstart vom Dienst bestätigt";}
    else if(response.stage==3 && response.rc1==0x80940010u && response.rc2==0x80940010u){
        response.status=LaunchStatus::queued;response.message="Spielstart vom Dienst eingereiht";
    }else{
        response.status=LaunchStatus::refused;
        response.message=response.stage==2?"Kein Benutzer angemeldet":"Startdienst lehnt den Start ab";
    }
    return response;
}
} // namespace ulg
