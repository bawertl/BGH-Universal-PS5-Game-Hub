// PS5 Universal Launcher - bounded, checksum-protected local state.
// SPDX-License-Identifier: MIT
#pragma once
#include "library_core.hpp"
#include <set>
#include <string>
#include <vector>
namespace ulg {
struct Preferences { std::set<std::string> favorites; std::vector<std::string> recent; };
// Only write these files in the launcher's OWN writable title storage, never inside a game tree.
bool write_catalogue_cache(const Catalogue &catalogue, const std::string &path);
bool read_catalogue_cache(const std::string &path, Catalogue &out);
bool write_preferences(const Preferences &preferences, const std::string &path);
bool read_preferences(const std::string &path, Preferences &out);
} // namespace ulg
