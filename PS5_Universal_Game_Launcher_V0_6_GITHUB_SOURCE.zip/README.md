# PS5 Universal Game Launcher V0.6 – Spieleordner & Diagnose

**Stand: 14.10.2026.** Fortsetzung der auf einer echten PS5 Firmware 13.60 gestarteten V0.5.

## Neue Funktionen

- POSIX-Suchpfadstatus mit echtem `errno` sowie Fehloperation `lstat`, `opendir`, `readdir` oder `type`.
- Einordnung `OK`, `Zugriff verweigert`, `nicht sichtbar`, `USB unsichtbar`, `kein Ordner`, `deaktiviert`, `FTP lesbar`.
- Gesamtzählung `failed_operations` samt Unterverzeichnissen und separater Zählung fehlgeschlagener Hauptpfade.
- DualSense-Ordnerverwaltung: `X` aktiviert/deaktiviert, `Quadrat` scannt neu, `Dreieck` öffnet den lesenden Ordnerbrowser, `Touchpad` bearbeitet den markierten Pfad mit Bildschirmtastatur, `L1/R1` wählt die Plattform für neue Pfade.
- Browser: `X` öffnet einen Unterordner, `Quadrat` übernimmt den aktuellen Ordner, `Dreieck` öffnet die manuelle Pfadeingabe, `Touchpad` geht zum übergeordneten Verzeichnis.
- Eigene Konfiguration **nur** unter `/download0/hui/ulg_v04/paths.user.conf`; keine Schreibzugriffe auf Spielverzeichnisse.
- Optionaler lokaler Read-only-FTP-Pfad über die **bereits laufende** ftpsrv v0.21.1 auf `127.0.0.1:2121` – `USER`, `TYPE I`, `CWD`, `PASV`, `MLSD`; keine Mutation, keine Installation oder Payload-Injektion.
- V0.5-GUI, Musik und bestehende Startadapter unverändert.

## Grenzen und Sicherheit

- FTP über localhost ist ein **experimenteller Fallback**. Zugriff einer PS5-Homebrew-App auf diese lokale Schnittstelle ist für **deine FW13.60 noch nicht verifiziert**. Wenn ftpsrv nicht läuft oder localhost blockiert ist, bleibt die POSIX-Diagnose sichtbar.
- Eine native Homebrew-App hat zunächst Sandbox-Zugriff. Es wird **keine** zusätzliche Berechtigungs-/Kernel-Anpassung ausgeführt, auch nicht über den optionalen Lapy-Payload. Externe Dateisystemzugriffe bleiben von der tatsächlichen Laufzeit abhänging.
- Die Hardwareprüfung von V0.5 belegt den Start der Grafik, **nicht** den Zugriff auf PS5-Spielordner. Diese V0.6 muss separat gebaut und auf der Konsole getestet werden.
- Der FTP-Fallback kann Spieltitel anhand von Dateinamen katalogisieren. Cover, die nur über FTP erreichbar sind, werden noch nicht automatisch heruntergeladen.
- Nur öffentliche GitHub-Tools; keine proprietären Sony-Dateien.

## Hosttests

```bash
python3 -m pytest -q tests
bash tooling/test_native_gui_syntax.sh
make -C native_ps5 CXX=g++
```

## Echter PS5-Build über GitHub Actions

Der Code baut auf `blackbearreloaded/ps5-homebrew-ui` Commit `bbe19054ee2e7ec069254775273aeb8846c4bd3e` auf. `tooling/build_native_ps5.sh` klont diese Quelle, wendet das Overlay an und erstellt auf einem netzfähigen Runner das **native** `eboot.bin`, `sce_module/libc.prx` und das PS5-Title-Paket. Die resultierende ZIP wird statisch validiert. **Ein lokal kompilierter Host-Test ist kein PS5-Build.**

Die V0.6 erfordert wegen des Dateisystemzugriffs keine Änderungen an etaHEN, kstuff, ShadowMountPlus oder an der Autoload-Konfiguration. Die App nutzt nur den bereits existierenden Launcher-Slot PPSA99079. Vor jeder Übertragung die bestehende V0.5 sichern.
