# V0.6: Fertigen PS5-Build mit dem vorhandenen GitHub Actions Runner erstellen

Dein privates Repo ist `bawertl/PS5-Universal-Game-Launcher`. Die V0.5 wurde dort bereits erfolgreich gebaut.

1. Lade die neue Datei `PS5_Universal_Game_Launcher_V0_6_GITHUB_SOURCE.zip` in das Repository hoch, **ohne sie zu entpacken**. `Commit changes` bestätigen.
2. Öffne die vorhandene `.github/workflows/ps5-build.yml` und wähle **Edit**. Ersetze den Inhalt durch die separat bereitgestellte `PS5_GITHUB_V0_6_BUILD.yml` bzw. kopiere den Workflow aus der ChatGPT-Nachricht hinein. `Commit changes` bestätigen.
3. Im Reiter **Actions** erscheint `PS5 Universal Launcher V0.6 - Build aus ZIP`. Bei erfolgreichem Abschluss lädt man das Artefakt herunter. Es enthält das native PS5-Paket. Bei Fehler die GitHub-Compilerlogs bereitstellen.
4. Die Hardwareversion V0.5 bleibt auf deiner Konsole unverändert, bis ein erfolgreicher V0.6-Build vorliegt und du die FTP-Aktualisierung selbst ausführst. Vor dem Update den vorhandenen Launcherordner `/data/homebrew/PPSA99079` sichern.

**Nicht** das Quellcode-ZIP auf der PS5 installieren: Dieses ist ausschließlich die Eingabe für den GitHub-Build. Erst die vom Runner erzeugte und überprüfte `PS5_Universal_Game_Launcher_V0_6_PPSA99079_PS5_TEST.zip` enthält `eboot.bin`, `sce_module/libc.prx` usw.
